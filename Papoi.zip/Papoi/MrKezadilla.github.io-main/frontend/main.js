/* ============================================
   CODEFLOW - main.js
   Punto de entrada: inicializa todos los módulos
   y registra los event listeners globales.
   Cargado último, después de todos los demás.
============================================ */

document.addEventListener('DOMContentLoaded', function () {

  // ── Boot sequence ────────────────────────────────────────────────────────
  PanelManager.init();
  FormManager.init();
  ContextMenuManager.init();
  DiagramRenderer.init();
  HighlightManager.init();

  AppEvents.on('ast:changed', () => EditorRenderer.render());
  AppEvents.on('ast:changed', () => DiagramRenderer.render());   // ← nueva
  AppEvents.on('ast:changed', () => HighlightManager.aplicar());   // ← nueva, va última

  // ── While infinite toggle: show/hide condition rows ──────────────────────
  const whileToggle = document.getElementById('whileIsInfinite');
  const whileCondRows = document.getElementById('whileConditionRows');
  if (whileToggle && whileCondRows) {
    whileToggle.addEventListener('change', () => {
      whileCondRows.style.display = whileToggle.checked ? 'none' : 'block';
      whileCondRows.querySelectorAll('[required]').forEach(el => {
        el.required = !whileToggle.checked;
      });
    });
  }
  StorageManager.loadLocal();

  // ── Toolbar buttons ──────────────────────────────────────────────────────
  document.getElementById('btnUndo').onclick  = () => HistoryManager.undo();
  document.getElementById('btnRedo').onclick  = () => HistoryManager.redo();
  document.getElementById('btnClear').onclick = () => { if (confirm("¿Reiniciar?")) ASTManager.reset(); };

  document.getElementById('btnTranspile').onclick = () => {
    if (typeof window.ApiBridge !== 'undefined') {
      window.ApiBridge.showPreviewModal();
    } else {
      // Fallback: show raw JSON if backend is not running
      const title = document.querySelector('#panelPythonCode .floating-panel-title');
      if (title) title.textContent = 'AST / Tokens (JSON)';
      const output = document.getElementById('pythonCodeOutput');
      output.innerText = typeof window.ASTExporter !== 'undefined'
        ? window.ASTExporter.generateJSON()
        : '// ERROR: api-bridge.js no está cargado.';
      PanelManager.open('panelPythonCode');
    }
  };

  const btnCopyPython = document.getElementById('btnCopyPython');
  if (btnCopyPython) {
    btnCopyPython.onclick = () => {
      navigator.clipboard.writeText(document.getElementById('pythonCodeOutput').innerText);
      alert("JSON copiado al portapapeles. ¡Listo para leerse en un Transpilador!");
    };
  }

  const btnMultiSelect = document.getElementById('btnMultiSelect');
  if (btnMultiSelect) { btnMultiSelect.onclick = (e) => { e.preventDefault(); SelectionManager.toggleMode(); }; }

  const btnDeleteSelected = document.getElementById('btnDeleteSelected');
  if (btnDeleteSelected) { btnDeleteSelected.onclick = (e) => { e.preventDefault(); SelectionManager.deleteSelected(); }; }

  // ── Global click handler (context menus) ─────────────────────────────────
  document.addEventListener('click', e => {
    // Quick context menu (+ button)
    const it = e.target.closest('#quickContextMenu .context-menu-item');
    if (it && !it.classList.contains('disabled')) {
      document.getElementById('quickContextMenu').style.display = 'none';
      const panelMap = {
        'open-create-var':  'panelManageVars',
        'open-function':    'panelManageFuncs',
        'open-assign':      'panelFormAssign',
        'open-read':        'panelFormRead',
        'open-show':        'panelFormShow',
        'open-if':          'panelFormIf',
        'open-while':       'panelFormWhile',
        'open-for':         'panelFormFor',
        'open-call-func':   'panelFormCallFunc'
      };
      if (it.dataset.action === 'open-def-func') {
        alert("Las funciones se gestionan desde el panel de Funciones. Su cuerpo aparece en la cabecera 'Funciones' arriba del editor, donde puedes añadir o quitar instrucciones dentro.");
        PanelManager.open('panelManageFuncs');
      } else if (panelMap[it.dataset.action]) {
        PanelManager.open(panelMap[it.dataset.action]);
      } else if (it.dataset.action === 'open-break') {
        ASTManager.addNode('break', {}, FormManager.targetId, FormManager.insertAfterId, FormManager.replaceNodeId);
      }
    }

    // Edit context menu (✎ button)
    const editIt = e.target.closest('#editContextMenu .context-menu-item');
    if (editIt && !editIt.classList.contains('disabled')) {
      document.getElementById('editContextMenu').style.display = 'none';
      if (editIt.dataset.action === 'edit-node') {
        FormManager.loadNodeForEdit(FormManager.activeNode);
      } else if (editIt.dataset.action === 'replace-node') {
        const n = FormManager.activeNode;
        ContextMenuManager.show(e.clientX, e.clientY, n.parentId, null, n.id);
      }
    }

    // Close menus on outside click
    if (!e.target.closest('.plus-icon') && !e.target.closest('.down-btn') &&
        !e.target.closest('.edit-icon') && !e.target.closest('.context-menu-popup')) {
      document.getElementById('quickContextMenu').style.display = 'none';
      const editMenu = document.getElementById('editContextMenu');
      if (editMenu) editMenu.style.display = 'none';
    }
  });

  // ── Cross-tab storage sync ────────────────────────────────────────────────
  window.addEventListener('storage', (e) => {
    if (e.key === StorageManager.KEY && e.newValue) {
      try {
        const s = JSON.parse(e.newValue);
        if (StorageManager._validateSchema(s)) {
          ASTManager.root         = StorageManager._sanitizeAST(s.ast);
          VariableRegistry._vars  = new Map(s.vars);
          FunctionRegistry._funcs = new Map(s.funcs.map(StorageManager._sanitizeFunc).filter(Boolean));
          AppEvents.emit('ast:changed');
          PanelManager.renderVarsList();
          PanelManager.renderFuncsList();
          FormManager.updateAllSelects();
        }
      } catch (_) {}
    }
  });

  console.log("CodeFlow v05.1 Ready — Modular Build");
});
