/* ============================================
   CODEFLOW - EXPORTADOR AST (Módulo)
   - buildTree()        → array de nodos limpios (sin parentId)
   - buildDocument()    → objeto con variables + funciones + ast
   - generateJSON()     → el documento completo, ya serializado

   F10: antes generateJSON() solo devolvía el árbol. Un AST sin el registro
   de variables es inservible: todos los varId apuntan a nada, el archivo no
   se puede reimportar ni sirve como respaldo. Ahora el documento incluye
   las tres partes.
============================================ */

(function () {

  const FORMATO = 1;   // versión del formato de archivo, no de la app

  /* Quita parentId y deja solo lo que define el programa. */
  const limpiarNodos = (nodes) => {
    if (!Array.isArray(nodes)) return [];
    return nodes.map(n => {
      const limpio = { id: n.id, type: n.type, data: n.data };
      if (n.children     !== null && n.children     !== undefined) limpio.children     = limpiarNodos(n.children);
      if (n.elseChildren !== null && n.elseChildren !== undefined) limpio.elseChildren = limpiarNodos(n.elseChildren);
      return limpio;
    });
  };

  window.ASTExporter = {

    /* Solo el árbol principal. Es lo que consume el transpilador. */
    buildTree: function () {
      if (typeof ASTManager === 'undefined' || !ASTManager.root) return [];
      return limpiarNodos(ASTManager.root.children);
    },

    buildVariables: function () {
      if (typeof VariableRegistry === 'undefined') return [];
      return VariableRegistry.getAll().map(v => ({
        id: v.id, name: v.name, type: v.type, value: v.value
      }));
    },

    buildFunctions: function () {
      if (typeof FunctionRegistry === 'undefined') return [];
      return FunctionRegistry.getAll().map(f => ({
        id:          f.id,
        name:        f.name,
        argVarId:    f.argVarId    || null,
        returnVarId: f.returnVarId || null,
        children:    limpiarNodos(f.children)
      }));
    },

    /* El programa completo: lo único reimportable. */
    buildDocument: function () {
      return {
        formato:   FORMATO,
        app:       'CodeFlow',
        exportado: new Date().toISOString(),
        variables: this.buildVariables(),
        functions: this.buildFunctions(),
        ast:       this.buildTree()
      };
    },

    generateJSON: function () {
      if (typeof ASTManager === 'undefined' || !ASTManager.root) {
        return JSON.stringify({ error: "ASTManager no está disponible" }, null, 4);
      }
      return JSON.stringify(this.buildDocument(), null, 4);
    }
  };

  console.log("Módulo Exportador de AST (JSON) cargado correctamente.");
})();