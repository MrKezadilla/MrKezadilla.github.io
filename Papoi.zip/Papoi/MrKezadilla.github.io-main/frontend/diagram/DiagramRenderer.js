/* ============================================================================
   DiagramRenderer.js — Dibuja el modelo de flujo como diagrama vertical clásico
   ----------------------------------------------------------------------------
   Trabaja en dos fases:
     1. MEDIR  — cada item declara cuánto ocupa a la izquierda y derecha de su
                 eje vertical ("espina"), y su altura. Recursivo.
     2. COLOCAR— con esas medidas se asignan coordenadas absolutas y se generan
                 las figuras y los caminos.

   Las ramas de un 'if' se abren a los lados y RECONVERGEN abajo.
   Los bucles retornan por la izquierda y salen por la derecha.
   ========================================================================== */

const DiagramRenderer = {

  // --------------------------------------------------------------- constantes
  W:    230,   // ancho de caja
  H:     46,   // alto de caja
  DW:   240,   // ancho de rombo / hexágono
  DH:    66,   // alto de rombo / hexágono
  GY:    38,   // separación vertical entre items
  GX:    30,   // separación horizontal entre carriles de un if
  LOOP:  30,   // holgura lateral para el retorno de bucle
  PAD:   28,   // margen del lienzo
  CARRIL_MIN: 44,  // ancho mínimo de una rama vacía

  contenedor: null,
  _cache: null,
  _figuras: null,
  _caminos: null,
  _textos: null,

  // ------------------------------------------------------------------ público

  init() {
    DiagramRenderer.contenedor = document.getElementById('diagramCanvas');
  },

  render() {
    const cont = DiagramRenderer.contenedor;
    if (!cont) return;

    const raiz = (typeof ASTManager !== 'undefined' && ASTManager.root)
      ? ASTManager.root.children : [];

    if (!raiz || raiz.length === 0) {
      cont.innerHTML =
        '<div class="diagram-vacio">' +
          '<div class="diagram-vacio-icono">❖</div>' +
          '<p>El diagrama aparecerá aquí</p>' +
        '</div>';
      return;
    }

    const modelo = AstWalker.recorrer(raiz);
    cont.innerHTML = DiagramRenderer._svg(modelo);
  },

  // --------------------------------------------------------------- generación

  _svg(modelo) {
    DiagramRenderer._cache   = new Map();
    DiagramRenderer._figuras = [];
    DiagramRenderer._caminos = [];
    DiagramRenderer._textos  = [];

    const D = DiagramRenderer;
    const secuencia = [modelo.inicio, ...modelo.cuerpo, modelo.fin];

    const m      = D._medirSeq(secuencia);
    const ancho  = m.izq + m.der + D.PAD * 2;
    const alto   = m.h + D.PAD * 2;
    const espina = m.izq + D.PAD;

    D._colocarSeq(secuencia, espina, D.PAD);

    return `<svg class="diagram-svg" width="${Math.ceil(ancho)}" height="${Math.ceil(alto)}"
      viewBox="0 0 ${Math.ceil(ancho)} ${Math.ceil(alto)}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <marker id="flecha" viewBox="0 0 10 10" refX="9" refY="5"
                markerWidth="6" markerHeight="6" orient="auto-start-reverse">
          <path d="M 0 0 L 10 5 L 0 10 z" fill="#94a3b8"/>
        </marker>
      </defs>
      <g class="diagram-caminos">${D._caminos.join('')}</g>
      <g class="diagram-figuras">${D._figuras.join('')}</g>
      <g class="diagram-textos">${D._textos.join('')}</g>
    </svg>`;
  },

  // ------------------------------------------------------------------- MEDIR

  _medirSeq(items) {
    const D = DiagramRenderer;
    if (!items || items.length === 0) {
      return { izq: 0, der: 0, h: 0, vacio: true };
    }
    let izq = 0, der = 0, h = 0;
    items.forEach((it, i) => {
      const m = D._medir(it);
      izq = Math.max(izq, m.izq);
      der = Math.max(der, m.der);
      h  += m.h + (i > 0 ? D.GY : 0);
    });
    return { izq, der, h, vacio: false };
  },

  _medir(item) {
    const D = DiagramRenderer;
    if (D._cache.has(item)) return D._cache.get(item);

    let m;

    if (item.clase === 'paso') {
      m = { izq: D.W / 2, der: D.W / 2, h: D.H };

    } else if (item.clase === 'decision') {
      const si = D._medirSeq(item.si);
      const no = D._medirSeq(item.no);
      const aSi = si.vacio ? D.CARRIL_MIN : si.izq + si.der;
      const aNo = no.vacio ? D.CARRIL_MIN : no.izq + no.der;
      const total = aSi + D.GX + aNo;
      const mitad = Math.max(D.DW / 2, total / 2);
      m = {
        izq: mitad,
        der: mitad,
        h:   D.DH + D.GY + Math.max(si.h, no.h, 20) + D.GY
      };

    } else { // bucle
      const c = D._medirSeq(item.cuerpo);
      const cIzq = c.vacio ? D.W / 2 : c.izq;
      const cDer = c.vacio ? D.W / 2 : c.der;
      m = {
        izq: Math.max(D.DW / 2, cIzq) + D.LOOP,
        der: Math.max(D.DW / 2, cDer) + D.LOOP,
        h:   D.DH + D.GY + Math.max(c.h, 20) + D.GY
      };
    }

    DiagramRenderer._cache.set(item, m);
    return m;
  },

  // ----------------------------------------------------------------- COLOCAR

  /** @returns {{finY:number, alcanzable:boolean}} */
  _colocarSeq(items, x, y) {
    const D = DiagramRenderer;
    if (!items || items.length === 0) return { finY: y, alcanzable: true };

    let cur = y, fin = y, alcanzable = true, primero = true;

    for (const item of items) {
      if (!alcanzable) break;               // código inalcanzable: no se dibuja
      if (!primero) D._flecha(x, fin, x, cur);
      const r = D._colocar(item, x, cur);
      fin = r.finY;
      alcanzable = r.alcanzable;
      cur = fin + D.GY;
      primero = false;
    }
    return { finY: fin, alcanzable };
  },

  _colocar(item, x, y) {
    const D = DiagramRenderer;

    // -------------------------------------------------------------- paso
    if (item.clase === 'paso') {
      D._figura(item, x, y, D.W, D.H);
      return { finY: y + D.H, alcanzable: item.sigue !== false };
    }

    // ---------------------------------------------------------- decisión
    if (item.clase === 'decision') {
      D._figura(item, x, y, D.DW, D.DH, 'decision');

      const si = D._medirSeq(item.si);
      const no = D._medirSeq(item.no);
      const aSi = si.vacio ? D.CARRIL_MIN : si.izq + si.der;
      const aNo = no.vacio ? D.CARRIL_MIN : no.izq + no.der;
      const total = aSi + D.GX + aNo;
      const borde = x - total / 2;

      const xSi = si.vacio ? borde + aSi / 2 : borde + si.izq;
      const xNo = no.vacio ? borde + aSi + D.GX + aNo / 2
                           : borde + aSi + D.GX + no.izq;

      const medioY = y + D.DH / 2;
      const ramaY  = y + D.DH + D.GY;

      D._camino([[x - D.DW / 2, medioY], [xSi, medioY], [xSi, ramaY]], true);
      D._camino([[x + D.DW / 2, medioY], [xNo, medioY], [xNo, ramaY]], true);
      D._rotulo('Sí', (x - D.DW / 2 + xSi) / 2, medioY - 7);
      D._rotulo('No', (x + D.DW / 2 + xNo) / 2, medioY - 7);

      const rSi = D._colocarSeq(item.si, xSi, ramaY);
      const rNo = D._colocarSeq(item.no, xNo, ramaY);

      const uneY = Math.max(rSi.finY, rNo.finY) + D.GY;
      if (rSi.alcanzable) D._camino([[xSi, rSi.finY], [xSi, uneY], [x, uneY]], false);
      if (rNo.alcanzable) D._camino([[xNo, rNo.finY], [xNo, uneY], [x, uneY]], false);

      return { finY: uneY, alcanzable: rSi.alcanzable || rNo.alcanzable };
    }

    // ------------------------------------------------------------- bucle
    const forma = item.forma === 'preparacion' ? 'preparacion' : 'decision';
    D._figura(item, x, y, D.DW, D.DH, forma);

    const m       = D._medir(item);
    const medioY  = y + D.DH / 2;
    const cuerpoY = y + D.DH + D.GY;

    D._camino([[x, y + D.DH], [x, cuerpoY]], true);
    if (forma === 'decision' && !item.infinito) D._rotulo('Sí', x + 14, cuerpoY - 12);

    const r      = D._colocarSeq(item.cuerpo, x, cuerpoY);
    const fondo  = Math.max(r.finY, cuerpoY + 20);
    const retY   = fondo + D.GY * 0.55;
    const salY   = retY + D.GY * 0.45;

    // retorno por la izquierda
    if (r.alcanzable) {
      const xRet = x - m.izq + 12;
      D._camino([[x, fondo], [x, retY], [xRet, retY],
                 [xRet, medioY], [x - D.DW / 2, medioY]], true);
    }

    // salida por la derecha
    if (item.infinito) return { finY: salY, alcanzable: false };

    const xSal = x + m.der - 12;
    D._camino([[x + D.DW / 2, medioY], [xSal, medioY], [xSal, salY], [x, salY]], false);
    if (forma === 'decision') D._rotulo('No', (x + D.DW / 2 + xSal) / 2, medioY - 7);

    return { finY: salY, alcanzable: true };
  },

  // ------------------------------------------------------------------ dibujo

  _figura(item, cx, top, w, h, forma) {
    const D = DiagramRenderer;
    const f = forma || item.forma || 'proceso';
    const x = cx - w / 2, y = top;
    const col = D._colores(f);
    let shape;

    switch (f) {
      case 'terminal':
        shape = `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${h / 2}"/>`;
        break;
      case 'io':
        shape = `<polygon points="${x + 16},${y} ${x + w},${y} ${x + w - 16},${y + h} ${x},${y + h}"/>`;
        break;
      case 'decision':
        shape = `<polygon points="${cx},${y} ${x + w},${y + h / 2} ${cx},${y + h} ${x},${y + h / 2}"/>`;
        break;
      case 'preparacion':
        shape = `<polygon points="${x + 22},${y} ${x + w - 22},${y} ${x + w},${y + h / 2} ${x + w - 22},${y + h} ${x + 22},${y + h} ${x},${y + h / 2}"/>`;
        break;
      case 'subrutina':
        shape = `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="4"/>` +
                `<line x1="${x + 10}" y1="${y}" x2="${x + 10}" y2="${y + h}"/>` +
                `<line x1="${x + w - 10}" y1="${y}" x2="${x + w - 10}" y2="${y + h}"/>`;
        break;
      default:
        shape = `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="6"/>`;
    }

    // Ancho útil: el rombo se estrecha al centro y el paralelogramo pierde
    // espacio en los cortes diagonales.
    const util   = (f === 'decision') ? w * 0.58 : (f === 'io' ? w - 48 : w - 24);
    const lineas = D._lineas(item.textoCompleto || item.texto || '', util, 2);

    D._figuras.push(
      `<g data-node-id="${D._esc(item.id)}" fill="${col.relleno}" stroke="${col.borde}" stroke-width="1.6">
         ${shape}
         <title>${D._esc(item.textoCompleto || '')}</title>
       </g>`
    );

    const tspans = lineas.map((l, i) => {
      const dy = lineas.length === 1 ? '0' : (i === 0 ? '-0.55em' : '1.15em');
      return `<tspan x="${cx}" dy="${dy}">${D._esc(l)}</tspan>`;
    }).join('');

    D._textos.push(
      `<text x="${cx}" y="${y + h / 2}" text-anchor="middle" dominant-baseline="central"
             font-family="monospace" font-size="12" fill="#0f172a">${tspans}</text>`
    );
  },

  _colores(f) {
    switch (f) {
      case 'terminal':    return { relleno: '#ecfdf5', borde: '#10b981' };
      case 'io':          return { relleno: '#f5f3ff', borde: '#7c3aed' };
      case 'decision':
      case 'preparacion': return { relleno: '#fffbeb', borde: '#f59e0b' };
      case 'subrutina':   return { relleno: '#eff6ff', borde: '#2563eb' };
      default:            return { relleno: '#eff6ff', borde: '#2563eb' };
    }
  },

  _camino(puntos, conFlecha) {
    const d = puntos.map((p, i) => (i ? 'L' : 'M') + p[0] + ' ' + p[1]).join(' ');
    DiagramRenderer._caminos.push(
      `<path d="${d}" fill="none" stroke="#94a3b8" stroke-width="1.6"
             stroke-linejoin="round"${conFlecha ? ' marker-end="url(#flecha)"' : ''}/>`
    );
  },

  _flecha(x1, y1, x2, y2) {
    DiagramRenderer._camino([[x1, y1], [x2, y2]], true);
  },

  _rotulo(t, x, y) {
    DiagramRenderer._textos.push(
      `<text x="${x}" y="${y}" text-anchor="middle"
             font-family="sans-serif" font-size="11" font-weight="600"
             fill="#475569">${DiagramRenderer._esc(t)}</text>`
    );
  },

  // ----------------------------------------------------------------- auxiliares

  /* Parte el texto en hasta `maxLineas` renglones según el ancho disponible.
     Estima ~7px por carácter con la fuente monoespaciada a 12px. */
  _lineas(s, anchoPx, maxLineas) {
    const max = Math.max(6, Math.floor(anchoPx / 7));
    if (s.length <= max) return [s];

    const palabras = s.split(' ');
    const out = [];
    let cur = '';
    for (const p of palabras) {
      const cand = cur ? cur + ' ' + p : p;
      if (cand.length <= max) { cur = cand; continue; }
      if (cur) out.push(cur);
      cur = p;
      if (out.length === maxLineas) { cur = ''; break; }
    }
    if (cur && out.length < maxLineas) out.push(cur);

    const escrito = out.join(' ');
    if (escrito.length < s.length) {
      const u = out[out.length - 1];
      out[out.length - 1] = (u.length >= max ? u.slice(0, max - 1) : u) + '…';
    }
    return out;
  },

  _esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
};