/* ============================================================================
   AstWalker.js — Recorre el AST y produce un modelo de flujo intermedio.
   ----------------------------------------------------------------------------
   No dibuja. No conoce SVG, coordenadas ni píxeles. Solo traduce el árbol de
   CodeFlow a una estructura que describe el FLUJO del programa, con las
   etiquetas ya resueltas a nombres reales de variables y funciones.

   Salida de recorrer():
     {
       inicio: <item terminal>,
       cuerpo: [ <item>, ... ],
       fin:    <item terminal>
     }

   Tipos de item (campo "clase"):
     paso      → una sola caja.  { id, forma, texto, textoCompleto, sigue }
     decision  → un rombo con dos ramas. { id, texto, si:[], no:[] }
     bucle     → un rombo con cuerpo y retorno. { id, texto, cuerpo:[], infinito }

   Formas (campo "forma"), usadas por el renderizador para elegir el dibujo:
     terminal | proceso | io | decision | preparacion | subrutina

   El campo "sigue" indica si el flujo continúa después del item.
   Es false en 'break': lo que venga después no se conecta.
   ========================================================================== */

const AstWalker = {

  /* Largo máximo de una etiqueta antes de recortarla con puntos suspensivos.
     El texto completo se conserva en textoCompleto para el tooltip. */
  MAX_ETIQUETA: 72,

  // ---------------------------------------------------------------- público

  /**
   * @param {Array}  ast   Nodos del programa (normalmente ASTManager.root.children)
   * @param {Object} opts  { vars, funcs } — registros. Por defecto los globales.
   */
  recorrer(ast, opts) {
    const ctx = {
      vars:  (opts && opts.vars)  || VariableRegistry,
      funcs: (opts && opts.funcs) || FunctionRegistry
    };

    return {
      inicio: AstWalker._terminal('__inicio__', 'Inicio'),
      cuerpo: AstWalker._secuencia(ast, ctx),
      fin:    AstWalker._terminal('__fin__', 'Fin')
    };
  },

  // --------------------------------------------------------------- recorrido

  _secuencia(nodos, ctx) {
    if (!Array.isArray(nodos)) return [];
    const salida = [];
    for (const n of nodos) {
      const item = AstWalker._item(n, ctx);
      if (item) salida.push(item);
    }
    return salida;
  },

  _item(node, ctx) {
    if (!node || !node.type) return null;
    const d = node.data || {};

    switch (node.type) {

      case 'show':
        return AstWalker._paso(node.id, 'io',
          'escribir ' + AstWalker._txtPartes(d.parts, ctx));

      case 'read':
        return AstWalker._paso(node.id, 'io',
          'leer ' + AstWalker._nombreVar(d.targetVarId, ctx));

      case 'assign':
        return AstWalker._paso(node.id, 'proceso', AstWalker._txtAssign(d, ctx));

      case 'function_call':
        return AstWalker._paso(node.id, 'subrutina', AstWalker._txtLlamada(d, ctx));

      case 'break':
        // sigue:false — el flujo no continúa hacia el siguiente item.
        // La flecha de salto hacia el final del bucle todavía NO se dibuja.
        return AstWalker._paso(node.id, 'proceso', 'romper bucle', false);

      case 'if':
        return {
          clase: 'decision',
          id:    node.id,
          ...AstWalker._etiqueta(AstWalker._txtCondicion(d.condition, ctx)),
          si:    AstWalker._secuencia(node.children, ctx),
          no:    AstWalker._secuencia(node.elseChildren, ctx)
        };

      case 'while':
        return {
          clase:    'bucle',
          id:       node.id,
          forma:    'decision',
          infinito: !!d.isInfinite,
          ...AstWalker._etiqueta(
            d.isInfinite ? 'siempre' : AstWalker._txtCondicion(d.condition, ctx)
          ),
          cuerpo:   AstWalker._secuencia(node.children, ctx)
        };

      case 'for':
        return {
          clase:    'bucle',
          id:       node.id,
          forma:    'preparacion',
          infinito: false,
          ...AstWalker._etiqueta(AstWalker._txtFor(d, ctx)),
          cuerpo:   AstWalker._secuencia(node.children, ctx)
        };

      // Nodo legado: la UI ya no lo genera, pero puede existir en proyectos viejos.
      case 'loop':
        return {
          clase:    'bucle',
          id:       node.id,
          forma:    'decision',
          infinito: true,
          ...AstWalker._etiqueta('siempre'),
          cuerpo:   AstWalker._secuencia(node.children, ctx)
        };

      case 'empty':
        return null;

      default:
        // Degradación amable: un tipo desconocido no rompe el diagrama.
        return AstWalker._paso(node.id, 'proceso', '? ' + node.type);
    }
  },

  // ------------------------------------------------------------- constructores

  _terminal(id, texto) {
    return { clase: 'paso', id, forma: 'terminal', sigue: true,
             ...AstWalker._etiqueta(texto) };
  },

  _paso(id, forma, texto, sigue = true) {
    return { clase: 'paso', id, forma, sigue, ...AstWalker._etiqueta(texto) };
  },

  /* Devuelve { texto, textoCompleto } recortando si hace falta. */
  _etiqueta(t) {
    const completo = String(t == null ? '' : t);
    const texto = completo.length > AstWalker.MAX_ETIQUETA
      ? completo.slice(0, AstWalker.MAX_ETIQUETA - 1) + '…'
      : completo;
    return { texto, textoCompleto: completo };
  },

  // ---------------------------------------------------------------- etiquetas

  _nombreVar(id, ctx) {
    if (!id) return '?';
    const v = ctx.vars.get(id);
    return v ? v.name : '?';
  },

  /* Formatea un valor según el tipo declarado de la variable. */
  _literal(tipo, valor) {
    if (valor === undefined || valor === null) return '?';
    switch (tipo) {
      case 'string':  return '"' + valor + '"';
      case 'boolean': return (valor === true || valor === 'true') ? 'verdadero' : 'falso';
      case 'list':    return Array.isArray(valor) ? '[' + valor.join(', ') + ']' : '[]';
      default:        return String(valor);
    }
  },

  _txtPartes(parts, ctx) {
    if (!Array.isArray(parts) || !parts.length) return '""';
    return parts.map(p =>
      p.type === 'variable'
        ? AstWalker._nombreVar(p.varId, ctx)
        : '"' + (p.value == null ? '' : p.value) + '"'
    ).join(' + ');
  },

  _txtAssign(d, ctx) {
    const destino = AstWalker._nombreVar(d.targetVarId, ctx);
    const op      = d.operator || '=';
    const e       = d.expression || {};
    const valor   = e.type === 'variable'
      ? AstWalker._nombreVar(e.varId, ctx)
      : AstWalker._literal(e.valueType, e.value);
    return `${destino} ${op} ${valor}`;
  },

  _txtCondicion(c, ctx) {
    if (!c) return '?';
    const izq = AstWalker._nombreVar(c.leftVarId, ctx);
    const der = c.rightType === 'variable'
      ? AstWalker._nombreVar(c.rightVarId, ctx)
      : AstWalker._literal(c.leftType, c.rightValue);
    return `${izq} ${c.operator || '?'} ${der}`;
  },

  _txtFor(d, ctx) {
    const iter = d.iterName || 'i';
    if (d.subType === 'iterable') {
      return `${iter} en ${AstWalker._nombreVar(d.iterableVarId, ctx)}`;
    }
    const desde = (d.start === undefined || d.start === null) ? 0 : d.start;
    const hasta = (d.end   === undefined || d.end   === null) ? 0 : d.end;
    return `${iter} = ${desde} … ${hasta}`;
  },

  _txtLlamada(d, ctx) {
    const nombre = d.funcName || '?';
    const arg    = d.argVarId ? AstWalker._nombreVar(d.argVarId, ctx) : '';
    const llamada = `${nombre}(${arg})`;
    return d.targetVarId
      ? `${AstWalker._nombreVar(d.targetVarId, ctx)} = ${llamada}`
      : llamada;
  }
};