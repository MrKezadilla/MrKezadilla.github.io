/* ============================================================================
   HighlightManager.js — Resaltado bidireccional editor ⇄ diagrama
   ----------------------------------------------------------------------------
   Empareja por data-node-id, que ambas vistas ya emiten.
   Usa delegación de eventos sobre los contenedores, que sobreviven a los
   re-render; por eso solo hace falta init() una vez.
   ========================================================================== */

const HighlightManager = {

  activoId: null,
  _editor:   null,
  _diagrama: null,

  init() {
    const H = HighlightManager;
    H._editor   = document.getElementById('codeLines');
    H._diagrama = document.getElementById('diagramCanvas');
    if (!H._editor || !H._diagrama) return;

    H._diagrama.addEventListener('mouseover', e => {
      const g = e.target.closest('[data-node-id]');
      if (g) H._hover(g.dataset.nodeId, true);
    });
    H._diagrama.addEventListener('mouseout', e => {
      const g = e.target.closest('[data-node-id]');
      if (g) H._hover(g.dataset.nodeId, false);
    });
    H._diagrama.addEventListener('click', e => {
      const g = e.target.closest('[data-node-id]');
      H._activar(g ? g.dataset.nodeId : null, 'editor');
    });

    H._editor.addEventListener('mouseover', e => {
      const l = e.target.closest('.editor-line[data-node-id]');
      if (l) H._hover(l.dataset.nodeId, true);
    });
    H._editor.addEventListener('mouseout', e => {
      const l = e.target.closest('.editor-line[data-node-id]');
      if (l) H._hover(l.dataset.nodeId, false);
    });
    H._editor.addEventListener('click', e => {
      // No interferir con el modo de selección múltiple ni con los botones de línea
      if (typeof SelectionManager !== 'undefined' && SelectionManager.active) return;
      if (e.target.closest('button, .plus-icon, .edit-icon, .down-btn, .line-del-btn')) return;
      const l = e.target.closest('.editor-line[data-node-id]');
      H._activar(l ? l.dataset.nodeId : null, 'diagrama');
    });
  },

  /* Reaplica el resaltado fijo después de un re-render. */
  aplicar() {
    const H = HighlightManager;
    if (!H.activoId) return;
    H._elementos(H.activoId).forEach(el => el.classList.add('hl-activo'));
  },

  _elementos(id) {
    const H = HighlightManager;
    const out = [];
    if (!id) return out;
    const sel = `[data-node-id="${id}"]`;
    if (H._editor)   { const l = H._editor.querySelector('.editor-line' + sel); if (l) out.push(l); }
    if (H._diagrama) { const g = H._diagrama.querySelector('g' + sel);          if (g) out.push(g); }
    return out;
  },

  _hover(id, on) {
    HighlightManager._elementos(id)
      .forEach(el => el.classList.toggle('hl-hover', on));
  },

  _activar(id, desplazar) {
    const H = HighlightManager;
    if (H.activoId) H._elementos(H.activoId).forEach(el => el.classList.remove('hl-activo'));

    // Click sobre lo ya activo: se apaga
    H.activoId = (H.activoId === id) ? null : id;
    if (!H.activoId) return;

    const els = H._elementos(H.activoId);
    els.forEach(el => el.classList.add('hl-activo'));

    const destino = desplazar === 'editor'
      ? els.find(el =>  el.classList.contains('editor-line'))
      : els.find(el => !el.classList.contains('editor-line'));
    if (destino && destino.scrollIntoView) {
      destino.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
    }
  }
};