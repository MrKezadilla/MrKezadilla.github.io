const AppEvents = {
  _subs: {},
  on:   (evt, fn) => (AppEvents._subs[evt] ||= []).push(fn),
  emit: (evt, payload) => (AppEvents._subs[evt] || []).forEach(fn => fn(payload))
};