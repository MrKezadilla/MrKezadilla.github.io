/* ============================================
   CODEFLOW - ASTManager
   El árbol de instrucciones. Operaciones:
   findNode, findParent, addNode, updateNode,
   deleteNode, purgeVarReferences, etc.
============================================ */

const ASTManager = {
  root: { id: 'root', type: 'program', children: [] },

  reset: () => {
    HistoryManager.saveState();
    ASTManager.root = { id: 'root', type: 'program', children: [] };
    FunctionRegistry.getAll().forEach(f => { f.children.length = 0; });
    if (typeof SelectionManager !== 'undefined') SelectionManager.clear();   // F18
    AppEvents.emit('ast:changed');
    StorageManager.saveLocal();
  },

  // ── Function wrapper cache ──────────────────────────────────────────────
  _funcWrappers: new Map(),

  _getWrapperForFunc: (f) => {
    let w = ASTManager._funcWrappers.get(f.id);
    if (!w) {
      w = { id: 'func:' + f.id, type: 'function_def_body', funcRef: f, children: f.children };
      ASTManager._funcWrappers.set(f.id, w);
    } else {
      w.children = f.children;
      w.funcRef  = f;
    }
    return w;
  },

  _syncWrapperToFunc: (wrapper) => {
    if (wrapper && wrapper.funcRef) {
      wrapper.funcRef.children = wrapper.children;
    }
  },

  _getAllContainers: () => {
    const containers = [ASTManager.root];
    FunctionRegistry.getAll().forEach(f => {
      containers.push(ASTManager._getWrapperForFunc(f));
    });
    return containers;
  },

  _afterMutate: (parent) => {
    if (parent && parent.funcRef) ASTManager._syncWrapperToFunc(parent);
  },

  // ── Tree traversal ──────────────────────────────────────────────────────

  /* Devuelve TODOS los hijos de un nodo: la rama normal y la rama else.
     Usar siempre esto en recorridos nuevos, para no repetir el olvido
     histórico de elseChildren. */
  _hijos: (node) => {
    if (!node) return [];
    const a = Array.isArray(node.children)     ? node.children     : [];
    const b = Array.isArray(node.elseChildren) ? node.elseChildren : [];
    return b.length ? a.concat(b) : a;
  },

  findNode: (id, node = null) => {
    if (node) {
      if (node.id === id) return node;
      // Contenedor virtual para ids "nodeId:else".
      // F1/F8: lleva parentId para que isAncestor e isInsideLoopByParentId
      // puedan seguir subiendo por la cadena.
      if (id && id.endsWith(':else') && node.id === id.slice(0, -5)) {
        return { id, type: '_else_container', parentNode: node, parentId: node.id,
                 children: node.elseChildren || [], get elseChildren(){ return null; } };
      }
      if (node.children) {
        for (let c of node.children) {
          const f = ASTManager.findNode(id, c);
          if (f) return f;
        }
      }
      if (Array.isArray(node.elseChildren)) {
        for (let c of node.elseChildren) {
          const f = ASTManager.findNode(id, c);
          if (f) return f;
        }
      }
      return null;
    }
    for (const container of ASTManager._getAllContainers()) {
      if (container.id === id) return container;
      const found = ASTManager.findNode(id, container);
      if (found) return found;
    }
    return null;
  },

  findParent: (targetId, node = null) => {
    if (node) {
      if (node.children && node.children.some(c => c.id === targetId)) return node;
      if (node.elseChildren && node.elseChildren.some(c => c.id === targetId)) {
        return { id: node.id + ':else', type: '_else_container', parentNode: node, parentId: node.id,
                 children: node.elseChildren,
                 get elseChildren(){ return null; } };
      }
      for (let c of (node.children || [])) {
        const found = ASTManager.findParent(targetId, c);
        if (found) return found;
      }
      for (let c of (node.elseChildren || [])) {
        const found = ASTManager.findParent(targetId, c);
        if (found) return found;
      }
      return null;
    }
    for (const container of ASTManager._getAllContainers()) {
      const found = ASTManager.findParent(targetId, container);
      if (found) return found;
    }
    return null;
  },

  isAncestor: (ancestorId, nodeId, visited = null) => {
    if (!visited) visited = new Set();
    if (visited.has(nodeId)) return false;
    visited.add(nodeId);
    const node = ASTManager.findNode(nodeId);
    if (!node) return false;
    if (node.parentId === ancestorId) return true;
    if (!node.parentId || node.parentId === 'root' ||
        (typeof node.parentId === 'string' && node.parentId.startsWith('func:'))) {
      return node.parentId === ancestorId;
    }
    return ASTManager.isAncestor(ancestorId, node.parentId, visited);
  },

  containsBreak: (node) => {
    if (!node) return false;
    if (node.type === 'break') return true;
    return ASTManager._hijos(node).some(c => ASTManager.containsBreak(c));   // F6
  },

  isInsideLoopByParentId: (parentId) => {
    if (!parentId || parentId === 'root' ||
        (typeof parentId === 'string' && parentId.startsWith('func:'))) return false;
    const node = ASTManager.findNode(parentId);
    if (!node) return false;
    if (['loop', 'while', 'for'].includes(node.type)) return true;
    return ASTManager.isInsideLoopByParentId(node.parentId);
  },

  // ── Reference cleanup ───────────────────────────────────────────────────

  /* F3/F4/F5: un solo recorrido que visita children Y elseChildren en todos
     los contenedores. La función recibe cada nodo y devuelve 'borrar' o null. */
  _limpiarArbol: (fn) => {
    const rec = (arr) => {
      if (!Array.isArray(arr)) return;
      for (let i = arr.length - 1; i >= 0; i--) {
        const c = arr[i];
        if (!c || typeof c !== 'object') { arr.splice(i, 1); continue; }
        if (fn(c) === 'borrar') { arr.splice(i, 1); continue; }
        rec(c.children);
        rec(c.elseChildren);
      }
    };
    rec(ASTManager.root.children);
    FunctionRegistry.getAll().forEach(f => rec(f.children));
  },

  purgeVarReferences: (varId) => {
    ASTManager._limpiarArbol((c) => {
      const d = c.data;
      if (!d) return null;

      // 1. Nodos que dejan de tener sentido: se eliminan
      if ((c.type === 'assign' || c.type === 'read') && d.targetVarId === varId) return 'borrar';
      if ((c.type === 'if' || c.type === 'while') && d.condition && d.condition.leftVarId === varId) return 'borrar';
      if (c.type === 'for' && d.iterableVarId === varId) return 'borrar';

      // 2. Referencias suaves: se degradan a un valor por defecto
      if (c.type === 'assign' && d.expression && d.expression.varId === varId) {
        const tv = VariableRegistry._vars.get(d.targetVarId);
        const vt = tv ? tv.type : 'string';
        d.expression = { type: 'literal', valueType: vt, value: Utils.getDefaultVal(vt) };
      }
      if ((c.type === 'if' || c.type === 'while') && d.condition && d.condition.rightVarId === varId) {
        d.condition.rightType  = 'literal';
        d.condition.rightValue = Utils.getDefaultVal(d.condition.leftType || 'string');
        delete d.condition.rightVarId;
      }
      if (c.type === 'function_call') {
        if (d.argVarId    === varId) d.argVarId    = null;
        if (d.targetVarId === varId) d.targetVarId = null;
      }
      if (c.type === 'show' && Array.isArray(d.parts)) {
        d.parts = d.parts.filter(p => !(p.type === 'variable' && p.varId === varId));
      }
      return null;
    });

    FunctionRegistry.getAll().forEach(f => {
      if (f.argVarId    === varId) f.argVarId    = null;
      if (f.returnVarId === varId) f.returnVarId = null;
    });
  },

  purgeFuncReferences: (funcName) => {
    ASTManager._limpiarArbol((c) =>
      (c.type === 'function_call' && c.data && c.data.funcName === funcName) ? 'borrar' : null
    );
  },

  renameFuncReferences: (oldName, newName) => {
    ASTManager._limpiarArbol((c) => {
      if (c.type === 'function_call' && c.data && c.data.funcName === oldName) c.data.funcName = newName;
      return null;
    });
  },

  // ── Mutations ───────────────────────────────────────────────────────────
  addNode: (type, data, parentId = 'root', insertAfter = null, replaceNodeId = null) => {
    const parent = ASTManager.findNode(parentId);
    if (!parent) return;
    // F17: para el contenedor virtual '_else_container', parent.children YA
    // apunta al array elseChildren del nodo real. No hace falta distinguir.
    const childArray = parent.children;
    if (!Array.isArray(childArray)) return;
    HistoryManager.saveState();
    const hasChildren = ['if', 'while', 'for', 'loop'].includes(type);
    const node = { id: Utils.generateId(), type, parentId, data, children: hasChildren ? [] : null };

    if (replaceNodeId) {
      const idx = childArray.findIndex(c => c.id === replaceNodeId);
      if (idx !== -1) childArray.splice(idx, 1, node);
      else childArray.push(node);
    } else if (insertAfter === 'START') {
      childArray.unshift(node);
    } else if (insertAfter) {
      const idx = childArray.findIndex(c => c.id === insertAfter);
      if (idx !== -1) childArray.splice(idx + 1, 0, node);
      else childArray.push(node);
    } else {
      childArray.push(node);
    }

    ASTManager._afterMutate(parent);
    AppEvents.emit('ast:changed');
    StorageManager.saveLocal();
  },

  updateNode: (id, newData) => {
    const node = ASTManager.findNode(id);
    if (!node) return;
    HistoryManager.saveState();
    node.data = newData;
    AppEvents.emit('ast:changed');
    StorageManager.saveLocal();
  },

  // ── else-aware mutations ────────────────────────────────────────────────
  addNodeWithElse: (type, data, hasElse, parentId = 'root', insertAfter = null, replaceNodeId = null) => {
    const parent = ASTManager.findNode(parentId);
    if (!parent || !Array.isArray(parent.children)) return;
    HistoryManager.saveState();
    const node = {
      id: Utils.generateId(), type, parentId, data,
      children:     [],
      elseChildren: (type === 'if' && hasElse) ? [] : null
    };
    if (replaceNodeId) {
      const idx = parent.children.findIndex(c => c.id === replaceNodeId);
      if (idx !== -1) parent.children.splice(idx, 1, node);
      else parent.children.push(node);
    } else if (insertAfter === 'START') {
      parent.children.unshift(node);
    } else if (insertAfter) {
      const idx = parent.children.findIndex(c => c.id === insertAfter);
      if (idx !== -1) parent.children.splice(idx + 1, 0, node);
      else parent.children.push(node);
    } else {
      parent.children.push(node);
    }
    ASTManager._afterMutate(parent);
    AppEvents.emit('ast:changed');
    StorageManager.saveLocal();
  },

  updateNodeWithElse: (id, newData, hasElse, existingElseChildren) => {
    const node = ASTManager.findNode(id);
    if (!node) return;
    HistoryManager.saveState();
    node.data = newData;
    if (hasElse) {
      node.elseChildren = existingElseChildren !== null ? existingElseChildren : [];
    } else {
      node.elseChildren = null;
    }
    AppEvents.emit('ast:changed');
    StorageManager.saveLocal();
  },

  deleteNode: (id) => {
    const node = ASTManager.findNode(id);
    if (!node) return;

    // F13: buscar el padre ANTES de tocar el historial, para no dejar
    // un paso de deshacer vacío si el borrado no se puede completar.
    const parent = ASTManager.findParent(id);
    if (!parent || !Array.isArray(parent.children)) return;

    // F14: la rama else también cuenta como contenido.
    const tieneContenido = ASTManager._hijos(node).length > 0;
    if (tieneContenido && !confirm("¿Borrar contenido?")) return;

    HistoryManager.saveState();
    const idx = parent.children.findIndex(n => n.id === id);
    if (idx !== -1) parent.children.splice(idx, 1);
    ASTManager._afterMutate(parent);
    SelectionManager.pruneDeadIds();
    AppEvents.emit('ast:changed');
    StorageManager.saveLocal();
  }
};

window.ASTManager = ASTManager;