/* ============================================
   CODEFLOW - VariableRegistry
   CRUD de variables. Cada variable tiene:
   { id, name, type, value }
   Depende de: Utils, HistoryManager, ASTManager,
               SelectionManager, PanelManager,
               FormManager, AppEvents, StorageManager
============================================ */

const VariableRegistry = {
  _vars: new Map(),

  /* F11: el nombre debe ser único en TODO el programa, no solo entre
     variables. Una variable y una función con el mismo nombre generan
     Python donde el 'def' sobrescribe la variable. */
  _nombreLibre: function(trimmed, exceptoId) {
    if ([...this._vars.values()].some(v => v.name === trimmed && v.id !== exceptoId))
      return "Ya existe una variable con ese nombre";
    if (typeof FunctionRegistry !== 'undefined' &&
        [...FunctionRegistry._funcs.values()].some(f => f.name === trimmed))
      return "Ya existe una función con ese nombre";
    return null;
  },

  create: function(name, type) {
    const reason = Utils.validateNameWithReason(name);
    if (reason) return { success: false, error: reason };
    const trimmed = name.trim();
    const choque  = this._nombreLibre(trimmed);
    if (choque) return { success: false, error: choque };
    HistoryManager.saveState();
    const id = Utils.generateId();
    this._vars.set(id, { id, name: trimmed, type, value: Utils.getDefaultVal(type) });
    this.notifyChange();
    return { success: true, id };
  },

  delete: function(id) {
    if (!confirm("¿Eliminar variable? Se quitarán también las referencias en el código.")) return;
    HistoryManager.saveState();
    this._vars.delete(id);
    ASTManager.purgeVarReferences(id);
    SelectionManager.pruneDeadIds();
    this.notifyChange();
  },

  get:    (id) => VariableRegistry._vars.get(id),
  getAll: ()   => Array.from(VariableRegistry._vars.values()),
  hasVars:()   => VariableRegistry._vars.size > 0,

  notifyChange: () => {
    PanelManager.renderVarsList();
    FormManager.updateAllSelects();
    AppEvents.emit('ast:changed');
    StorageManager.saveLocal();
  }
};

window.VariableRegistry = VariableRegistry;