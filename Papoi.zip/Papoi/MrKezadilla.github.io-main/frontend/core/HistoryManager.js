/* ============================================
   CODEFLOW - HistoryManager
   Pila de deshacer/rehacer (hasta 50 estados).
   Depende de: Utils, ASTManager, VariableRegistry,
               FunctionRegistry, AppEvents,
               PanelManager, FormManager, StorageManager
============================================ */

const HistoryManager = {
  stack: [], pointer: -1, limit: 50,

  _snapshot: function() {
    return {
      ast:   Utils.clone(ASTManager.root),
      vars:  Utils.clone(Array.from(VariableRegistry._vars.entries())),
      funcs: Utils.clone(Array.from(FunctionRegistry._funcs.entries()))
    };
  },

  /* Se llama SIEMPRE antes de mutar.
     Invariante: stack[pointer] refleja el estado actual; las posiciones
     anteriores son los estados a los que se puede volver.

     F9: en la primera llamada hay que apilar DOS veces. Una guarda el estado
     inicial (recuperable) y otra reserva la posición del estado actual. Sin
     eso, la segunda llamada sobrescribía el estado inicial y la primera
     acción quedaba fuera del alcance de deshacer. */
  saveState: function() {
    if (this.stack.length === 0) {
      this.stack.push(this._snapshot());
      this.pointer = 0;
    } else {
      this.stack[this.pointer] = this._snapshot();
    }

    if (this.pointer < this.stack.length - 1) {
      this.stack = this.stack.slice(0, this.pointer + 1);
    }

    this.stack.push(this._snapshot());
    if (this.stack.length > this.limit) this.stack.shift();
    this.pointer = this.stack.length - 1;
    this.updateUI();
  },

  undo: function() {
    if (this.pointer > 0) {
      this.stack[this.pointer] = this._snapshot();
      this.pointer--;
      this.restore(this.stack[this.pointer]);
    }
    this.updateUI();
  },

  redo: function() {
    if (this.pointer < this.stack.length - 1) {
      this.pointer++;
      this.restore(this.stack[this.pointer]);
    }
    this.updateUI();
  },

  restore: function(s) {
    if (!s) return;
    ASTManager.root          = Utils.clone(s.ast);
    VariableRegistry._vars   = new Map(Utils.clone(s.vars));
    FunctionRegistry._funcs  = new Map(Utils.clone(s.funcs));
    AppEvents.emit('ast:changed');
    if (typeof SelectionManager !== 'undefined') SelectionManager.pruneDeadIds();
    PanelManager.renderVarsList();
    PanelManager.renderFuncsList();
    FormManager.updateAllSelects();
    StorageManager.saveLocal();
  },

  updateUI: function() {
    const u = document.getElementById('btnUndo');
    const r = document.getElementById('btnRedo');
    if (u) u.style.opacity = (this.pointer > 0) ? '1' : '0.4';
    if (r) r.style.opacity = (this.pointer < this.stack.length - 1) ? '1' : '0.4';
  }
};

window.HistoryManager = HistoryManager;