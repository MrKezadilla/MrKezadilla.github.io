/* ============================================
   CODEFLOW - FunctionRegistry
   CRUD de funciones. Cada función tiene:
   { id, name, argVarId, returnVarId, children[] }
   Depende de: Utils, HistoryManager, ASTManager,
               SelectionManager, PanelManager,
               FormManager, AppEvents, StorageManager
============================================ */

const FunctionRegistry = {
  _funcs: new Map(),

  /* F11: el nombre debe ser único en TODO el programa, no solo entre
     funciones. Ver la nota equivalente en VariableRegistry. */
  _nombreLibre: function(trimmed, exceptoId) {
    if ([...this._funcs.values()].some(f => f.name === trimmed && f.id !== exceptoId))
      return "Ya existe una función con ese nombre";
    if (typeof VariableRegistry !== 'undefined' &&
        [...VariableRegistry._vars.values()].some(v => v.name === trimmed))
      return "Ya existe una variable con ese nombre";
    return null;
  },

  create: function(name) {
    const reason = Utils.validateNameWithReason(name);
    if (reason) return { success: false, error: reason };
    const trimmed = name.trim();
    const choque  = this._nombreLibre(trimmed);
    if (choque) return { success: false, error: choque };
    HistoryManager.saveState();
    const id = Utils.generateId();
    this._funcs.set(id, { id, name: trimmed, argVarId: null, returnVarId: null, children: [] });
    this.notifyChange();
    return { success: true, id };
  },

  delete: function(id) {
    if (!confirm("¿Eliminar función? Se quitarán también las llamadas en el código.")) return;
    const func  = this._funcs.get(id);
    const fname = func ? func.name : null;
    HistoryManager.saveState();
    this._funcs.delete(id);
    if (fname) ASTManager.purgeFuncReferences(fname);
    if (ASTManager._funcWrappers) ASTManager._funcWrappers.delete(id);
    SelectionManager.pruneDeadIds();
    this.notifyChange();
  },

  /* F12: antes se llamaba a saveState() y se aplicaban argVarId/returnVarId
     ANTES de validar el nombre. Si el nombre resultaba inválido se devolvía
     error, pero ya se había dejado un paso fantasma en el historial y
     aplicado los otros dos campos a medias. Ahora se valida todo primero. */
  update: function(id, partial) {
    const f = this._funcs.get(id);
    if (!f) return { success: false, error: "Función no encontrada" };

    let nombreNuevo = null;
    if (partial.name !== undefined) {
      const reason = Utils.validateNameWithReason(partial.name);
      if (reason) return { success: false, error: reason };
      const trimmed = partial.name.trim();
      const choque  = this._nombreLibre(trimmed, id);
      if (choque) return { success: false, error: choque };
      nombreNuevo = trimmed;
    }

    HistoryManager.saveState();

    if (partial.argVarId    !== undefined) f.argVarId    = partial.argVarId;
    if (partial.returnVarId !== undefined) f.returnVarId = partial.returnVarId;
    if (nombreNuevo !== null && nombreNuevo !== f.name) {
      const oldName = f.name;
      f.name = nombreNuevo;
      ASTManager.renameFuncReferences(oldName, nombreNuevo);
    }

    this.notifyChange();
    return { success: true };
  },

  get:    (id) => FunctionRegistry._funcs.get(id),
  getAll: ()   => Array.from(FunctionRegistry._funcs.values()),

  notifyChange: () => {
    PanelManager.renderFuncsList();
    FormManager.updateAllSelects();
    AppEvents.emit('ast:changed');
    StorageManager.saveLocal();
  }
};

window.FunctionRegistry = FunctionRegistry;