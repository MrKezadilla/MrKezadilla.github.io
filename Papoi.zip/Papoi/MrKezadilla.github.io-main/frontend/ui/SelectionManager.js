/* ============================================
   CODEFLOW - SelectionManager
   Multi-selección de nodos para borrado masivo.
   Depende de: ASTManager, EditorRenderer,
               StorageManager
============================================ */

const SelectionManager = {
  active:      false,
  selectedIds: new Set(),

  toggleMode: () => {
    SelectionManager.active = !SelectionManager.active;
    const btn = document.getElementById('btnMultiSelect');
    if (btn) btn.classList.toggle('active', SelectionManager.active);
    document.body.classList.toggle('selection-mode', SelectionManager.active);
    if (!SelectionManager.active) SelectionManager.clear();
  },

  toggleSelect: (nodeId, el) => {
    if (!SelectionManager.active || !nodeId) return;
    if (SelectionManager.selectedIds.has(nodeId)) {
      SelectionManager.selectedIds.delete(nodeId);
      el.classList.remove('selected');
    } else {
      SelectionManager.selectedIds.add(nodeId);
      el.classList.add('selected');
    }
    const delBtn = document.getElementById('btnDeleteSelected');
    if (delBtn) delBtn.style.display = SelectionManager.selectedIds.size > 0 ? 'inline-block' : 'none';
  },

  clear: () => {
    SelectionManager.selectedIds.clear();
    document.querySelectorAll('.editor-line.selected').forEach(el => el.classList.remove('selected'));
    const delBtn = document.getElementById('btnDeleteSelected');
    if (delBtn) delBtn.style.display = 'none';
  },

  deleteSelected: () => {
    if (SelectionManager.selectedIds.size === 0) return;
    if (confirm(`¿Borrar ${SelectionManager.selectedIds.size} instrucción(es) y todo su contenido?`)) {
      HistoryManager.saveState();
      SelectionManager.selectedIds.forEach(id => {
        const parent = ASTManager.findParent(id);
        if (parent) {
          const idx = parent.children.findIndex(n => n.id === id);
          if (idx !== -1) parent.children.splice(idx, 1);
          ASTManager._afterMutate(parent);
        }
      });
      SelectionManager.clear();
      AppEvents.emit('ast:changed');
      StorageManager.saveLocal();
    }
  },

  pruneDeadIds: () => {
    const before = SelectionManager.selectedIds.size;
    SelectionManager.selectedIds.forEach(id => {
      if (!ASTManager.findNode(id)) SelectionManager.selectedIds.delete(id);
    });
    if (before !== SelectionManager.selectedIds.size) {
      const delBtn = document.getElementById('btnDeleteSelected');
      if (delBtn) delBtn.style.display = SelectionManager.selectedIds.size > 0 ? 'inline-block' : 'none';
    }
  }
};

window.SelectionManager = SelectionManager;
