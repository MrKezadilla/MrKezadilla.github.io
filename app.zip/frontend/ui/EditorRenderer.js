/* ============================================
   CODEFLOW - EditorRenderer
   Convierte el AST en líneas DOM del editor.
   Depende de: Utils, ASTManager, VariableRegistry,
               FunctionRegistry, SelectionManager,
               DragManager, ContextMenuManager,
               PanelManager, FormManager
============================================ */

const EditorRenderer = {
  container:   document.getElementById('codeLines'),
  lineCounter: 1,
  MIN_LINES:   16,

  panels: {
    vars:  { open: true },
    funcs: { open: true }
  },

  // ── Main render entry point ─────────────────────────────────────────────
  render: () => {
    if (!EditorRenderer.container) return;
    EditorRenderer.container.innerHTML = '';
    EditorRenderer.lineCounter = 1;

    EditorRenderer._renderDeclarationHeader();
    EditorRenderer._visit(ASTManager.root.children, 0, 'root');

    if (ASTManager.root.children.length === 0) {
      EditorRenderer._createLine(null, 0, true, 'root');
    }

    const current = EditorRenderer.lineCounter;
    if (current < EditorRenderer.MIN_LINES) {
      for (let i = 0; i < (EditorRenderer.MIN_LINES - current); i++) {
        EditorRenderer._createEmptyLine();
      }
    }
  },

  // ── Declaration header (Variables + Functions sections) ─────────────────
  _renderDeclarationHeader: () => {
    EditorRenderer._createPanelHeader('vars');
    if (EditorRenderer.panels.vars.open) {
      const vars = VariableRegistry.getAll();
      if (vars.length === 0) {
        EditorRenderer._createPanelEmptyLine('vars');
      } else {
        vars.forEach((v, idx) => EditorRenderer._createPanelItemLine('var', v, idx, vars.length));
      }
    }

    EditorRenderer._createPanelHeader('funcs');
    if (EditorRenderer.panels.funcs.open) {
      const funcs = FunctionRegistry.getAll();
      if (funcs.length === 0) {
        EditorRenderer._createPanelEmptyLine('funcs');
      } else {
        funcs.forEach((f, idx) => {
          EditorRenderer._renderFunctionBlock(f);
          if (idx < funcs.length - 1) EditorRenderer._createPanelSeparator();
        });
      }
    }
  },

  _renderFunctionBlock: (func) => {
    const funcNode = {
      id:       'func:' + func.id,
      type:     'function_def',
      parentId: null,
      data:     { funcName: func.name, argVarId: func.argVarId, returnVarId: func.returnVarId, _funcId: func.id },
      children: func.children
    };
    EditorRenderer._createFunctionDefLine(funcNode, 1);
    if (func.children && func.children.length > 0) {
      EditorRenderer._visit(func.children, 2, funcNode.id);
    } else {
      EditorRenderer._createLine(null, 2, true, funcNode.id);
    }
    EditorRenderer._createReturnLine(funcNode, 2);
    EditorRenderer._createCloser(funcNode, 1);
  },

  // ── Panel header (collapsible Variables / Functions heading) ────────────
  _createPanelHeader: (kind) => {
    const el = document.createElement('div');
    el.className      = 'editor-line declaration-line declaration-header';
    el.draggable      = false;
    el.dataset.declaration = kind === 'vars' ? 'var-header' : 'func-header';

    const num = document.createElement('div');
    num.className  = 'line-number';
    num.innerText  = EditorRenderer.lineCounter++;

    const content = document.createElement('div');
    content.className = 'line-content indent-0';
    const open  = EditorRenderer.panels[kind].open;
    const arrow = open ? '▼' : '▶';
    const count = kind === 'vars' ? VariableRegistry.getAll().length : FunctionRegistry.getAll().length;
    const label = kind === 'vars' ? 'Variables' : 'Funciones';
    content.innerHTML = `<span class="panel-toggle-arrow">${arrow}</span> <span class="keyword">${label}</span> <span class="panel-count">(${count})</span>`;
    content.style.cursor = 'pointer';
    content.title  = open ? `Plegar ${label.toLowerCase()}` : `Desplegar ${label.toLowerCase()}`;
    content.onclick = (e) => {
      e.stopPropagation();
      EditorRenderer.panels[kind].open = !EditorRenderer.panels[kind].open;
      EditorRenderer.render();
    };

    el.append(EditorRenderer._hiddenHandle(), num, content,
              EditorRenderer._disabledBtn('down-btn', '↓'),
              EditorRenderer._disabledBtn('edit-icon'),
              EditorRenderer._disabledBtn('line-del-btn', '×'));
    EditorRenderer.container.appendChild(el);
  },

  // ── Panel item line (one variable or function entry) ────────────────────
  _createPanelItemLine: (kind, entity, idx, total) => {
    const el = document.createElement('div');
    el.className      = 'editor-line declaration-line declaration-item';
    el.draggable      = false;
    el.dataset.declaration = kind;

    const num = document.createElement('div');
    num.className = 'line-number';
    num.innerText = EditorRenderer.lineCounter++;

    const content = document.createElement('div');
    content.className = 'line-content indent-1';
    const esc = Utils.escapeHtml;

    if (kind === 'var') {
      const typeLabels = { boolean: 'Bool', list: 'List', number: 'Num', string: 'Texto' };
      const typeLabel  = typeLabels[entity.type] || entity.type;
      let valStr;
      if      (entity.type === 'boolean') valStr = `<span class="boolean">${entity.value ? 'True' : 'False'}</span>`;
      else if (entity.type === 'list')    valStr = `<span class="bracket">[ ]</span>`;
      else if (entity.type === 'string')  valStr = `<span class="string">"${esc(entity.value || '')}"</span>`;
      else                                valStr = `<span class="number">${esc(entity.value)}</span>`;
      content.innerHTML = `<span class="variable">${esc(entity.name)}</span><span class="operator">:</span> <span class="keyword">${esc(typeLabel)}</span> <span class="operator">=</span> ${valStr}`;
    } else {
      content.innerHTML = `<span class="variable">${esc(entity.name)}</span><span class="bracket">()</span>`;
    }

    el.append(EditorRenderer._hiddenHandle(), num, content,
              EditorRenderer._disabledBtn('down-btn', '↓'),
              EditorRenderer._disabledBtn('edit-icon'),
              EditorRenderer._disabledBtn('line-del-btn', '×'));
    EditorRenderer.container.appendChild(el);
  },

  _createPanelEmptyLine: (kind) => {
    const el = document.createElement('div');
    el.className = 'editor-line declaration-line declaration-item declaration-empty';
    el.draggable = false;

    const num = document.createElement('div');
    num.className = 'line-number';
    num.innerText = EditorRenderer.lineCounter++;

    const content = document.createElement('div');
    content.className = 'line-content indent-1';
    const txt = kind === 'vars'
      ? 'Sin variables — créalas desde el panel "Variables"'
      : 'Sin funciones — créalas desde el panel "Funciones"';
    content.innerHTML = `<span style="opacity:0.5; font-style:italic;">// ${txt}</span>`;

    el.append(EditorRenderer._hiddenHandle(), num, content,
              EditorRenderer._disabledBtn('down-btn'),
              EditorRenderer._disabledBtn('edit-icon'),
              EditorRenderer._disabledBtn('line-del-btn'));
    EditorRenderer.container.appendChild(el);
  },

  _createPanelSeparator: () => {
    const el = document.createElement('div');
    el.className = 'editor-line declaration-line declaration-separator';
    el.draggable = false;

    const num = document.createElement('div');
    num.className = 'line-number';
    num.innerText = '';

    const content = document.createElement('div');
    content.className = 'line-content indent-1';
    content.innerHTML = `<span class="panel-separator-line"></span>`;

    el.append(EditorRenderer._hiddenHandle(), num, content,
              EditorRenderer._disabledBtn('down-btn'),
              EditorRenderer._disabledBtn('edit-icon'),
              EditorRenderer._disabledBtn('line-del-btn'));
    EditorRenderer.container.appendChild(el);
  },

  // ── Function definition line ────────────────────────────────────────────
  _createFunctionDefLine: (funcNode, level) => {
    const el = document.createElement('div');
    el.className      = 'editor-line declaration-line function-def-line';
    el.draggable      = false;
    el.dataset.declaration = 'func';
    el.dataset.funcId      = funcNode.data._funcId;

    const num = document.createElement('div');
    num.className = 'line-number';
    num.innerText = EditorRenderer.lineCounter++;

    const content = document.createElement('div');
    content.className = `line-content indent-${level}`;
    content.innerHTML = EditorRenderer._html(funcNode);

    const dragHandle = document.createElement('div');
    dragHandle.className    = 'drag-handle';
    dragHandle.style.visibility = 'hidden';

    const downBtn = document.createElement('div');
    downBtn.className = 'down-btn';
    downBtn.innerText = '↓';
    downBtn.onclick   = (e) => { e.stopPropagation(); ASTManager.addNode('empty', {}, funcNode.id, 'START'); };

    const editBtn = document.createElement('div');
    editBtn.className = 'edit-icon';
    editBtn.innerText = '✎';
    editBtn.title     = 'Editar argumento y retorno de la función';
    editBtn.onclick   = (e) => { e.stopPropagation(); FormManager.loadFunctionForEdit(funcNode.data._funcId); };

    const del = document.createElement('div');
    del.className        = 'line-del-btn';
    del.innerText        = '×';
    del.style.opacity    = '0';
    del.style.pointerEvents = 'none';
    del.title            = 'Borra la función desde el panel de Funciones';

    el.append(dragHandle, num, content, downBtn, editBtn, del);
    EditorRenderer.container.appendChild(el);
  },

  // ── AST node traversal ──────────────────────────────────────────────────
  _visit: (nodes, level, parentId) => {
    nodes.forEach(n => {
      if (n.type === 'empty') {
        EditorRenderer._createLine(n, level, true, n.parentId);
      } else {
        EditorRenderer._createLine(n, level, false, null);
        if (n.children) {
          if (n.children.length > 0) {
            EditorRenderer._visit(n.children, level + 1, n.id);
          } else {
            EditorRenderer._createLine(null, level + 1, true, n.id);
          }
          EditorRenderer._createCloser(n, level);
        }
        // Render else branch immediately after the if's closing brace
        if (n.type === 'if' && n.elseChildren !== null && n.elseChildren !== undefined) {
          EditorRenderer._createElseHeader(n, level);
          if (n.elseChildren.length > 0) {
            EditorRenderer._visit(n.elseChildren, level + 1, n.id + ':else');
          } else {
            EditorRenderer._createLine(null, level + 1, true, n.id + ':else');
          }
          EditorRenderer._createElseCloser(n, level);
        }
      }
    });
  },

  // ── Regular code line ───────────────────────────────────────────────────
  _createLine: (n, level, isPlaceholder, targetId) => {
    const el = document.createElement('div');
    el.className = 'editor-line';

    if (n) {
      el.dataset.nodeId = n.id;
      el.draggable      = true;
      EditorRenderer._attachDragEvents(el, n.id);
      el.onclick = (e) => {
        if (SelectionManager.active) { e.stopPropagation(); SelectionManager.toggleSelect(n.id, el); }
      };
      if (SelectionManager.selectedIds.has(n.id)) el.classList.add('selected');
    }

    const num = document.createElement('div');
    num.className = 'line-number';
    num.innerText = EditorRenderer.lineCounter++;

    const content = document.createElement('div');
    content.className = `line-content indent-${Math.min(level, 5)}`;
    if (isPlaceholder) {
      content.innerHTML = n && n.type === 'empty'
        ? `<span style="opacity:0.2; font-style:italic;">// (Línea vacía)</span>`
        : `<span style="opacity:0.4; font-style:italic;">// Agregar instrucción...</span>`;
    } else {
      content.innerHTML = EditorRenderer._html(n);
    }

    const dragHandle = document.createElement('div');
    dragHandle.className = 'drag-handle';
    dragHandle.innerHTML = '⠿';
    dragHandle.title     = 'Arrastrar';

    const downBtn = document.createElement('div');
    downBtn.className = 'down-btn';
    downBtn.innerText = '↓';
    downBtn.onclick   = (e) => {
      e.stopPropagation();
      if (n && n.children !== null && n.children !== undefined) {
        ASTManager.addNode('empty', {}, n.id, 'START');
      } else {
        ASTManager.addNode('empty', {}, n ? n.parentId : targetId, n ? n.id : null);
      }
    };

    let actionBtn;
    if (isPlaceholder || (n && n.type === 'empty')) {
      actionBtn           = document.createElement('div');
      actionBtn.className = 'plus-icon';
      actionBtn.innerText = '+';
      actionBtn.onclick   = (e) => {
        e.stopPropagation();
        ContextMenuManager.show(e.clientX, e.clientY, n ? n.parentId : targetId, null, n && n.type === 'empty' ? n.id : null);
      };
    } else {
      actionBtn           = document.createElement('div');
      actionBtn.className = 'edit-icon';
      actionBtn.innerText = '✎';
      actionBtn.onclick   = (e) => { e.stopPropagation(); ContextMenuManager.showEditMenu(e.clientX, e.clientY, n); };
    }

    const del = document.createElement('div');
    del.className = 'line-del-btn';
    del.innerText = '×';
    if (n) {
      del.onclick = (e) => { e.stopPropagation(); ASTManager.deleteNode(n.id); };
    } else {
      del.style.opacity      = '0';
      del.style.pointerEvents = 'none';
    }

    el.append(dragHandle, num, content, downBtn, actionBtn, del);
    EditorRenderer.container.appendChild(el);
  },

  _createEmptyLine: () => {
    const el = document.createElement('div');
    el.className = 'editor-line';

    const num = document.createElement('div');
    num.className = 'line-number';
    num.innerText = EditorRenderer.lineCounter++;

    const content  = document.createElement('div');
    content.className = 'line-content';

    const downBtn  = document.createElement('div');
    downBtn.className = 'down-btn';
    downBtn.innerText = '↓';
    downBtn.onclick   = (e) => { e.stopPropagation(); ASTManager.addNode('empty', {}, 'root', null); };

    const plus      = document.createElement('div');
    plus.className  = 'plus-icon';
    plus.innerText  = '+';
    plus.onclick    = (e) => { e.stopPropagation(); ContextMenuManager.show(e.clientX, e.clientY, 'root', null, null); };

    el.append(EditorRenderer._hiddenHandle(), num, content, downBtn, plus, EditorRenderer._disabledBtn('line-del-btn', '×'));
    EditorRenderer.container.appendChild(el);
  },

  _createReturnLine: (node, level) => {
    const el = document.createElement('div');
    el.className = 'editor-line';

    const num = document.createElement('div');
    num.className = 'line-number';
    num.innerText = EditorRenderer.lineCounter++;

    const content = document.createElement('div');
    content.className = `line-content indent-${Math.min(level, 5)}`;
    const retVar  = node.data && node.data.returnVarId ? VariableRegistry.get(node.data.returnVarId) : null;
    const retText = retVar ? ` <span class="variable">${Utils.escapeHtml(retVar.name)}</span>` : '';
    content.innerHTML = `<span class="keyword">return</span>${retText}`;

    el.append(EditorRenderer._hiddenHandle(), num, content,
              EditorRenderer._disabledBtn('down-btn', '↓'),
              EditorRenderer._disabledBtn('plus-icon', '+'),
              EditorRenderer._disabledBtn('line-del-btn', '×'));
    EditorRenderer.container.appendChild(el);
  },

  _createCloser: (node, level) => {
    const el = document.createElement('div');
    el.className       = 'editor-line closer-line';
    el.dataset.closerFor = node.id;

    const num = document.createElement('div');
    num.className = 'line-number';
    num.innerText = EditorRenderer.lineCounter++;

    const content = document.createElement('div');
    content.className = `line-content indent-${level}`;
    content.innerHTML = `<span class="bracket">}</span> <span class="keyword">End</span>`;

    const dragHandle = EditorRenderer._hiddenHandle();

    const downBtn = document.createElement('div');
    downBtn.className = 'down-btn';
    downBtn.innerText = '↓';
    downBtn.onclick   = (e) => { e.stopPropagation(); ASTManager.addNode('empty', {}, node.parentId, node.id); };

    const plus    = document.createElement('div');
    plus.className = 'plus-icon';
    plus.innerText = '+';
    plus.onclick   = (e) => { e.stopPropagation(); ContextMenuManager.show(e.clientX, e.clientY, node.parentId, node.id, null); };

    el.append(dragHandle, num, content, downBtn, plus, EditorRenderer._disabledBtn('line-del-btn', '×'));
    EditorRenderer.container.appendChild(el);
  },

  // ── Drag event wiring ───────────────────────────────────────────────────
  _attachDragEvents: (el, nodeId) => {
    el.addEventListener('dragstart', (e) => {
      e.stopPropagation();
      DragManager.startDrag(nodeId);
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', nodeId);
      DragManager.draggingIds.forEach(id => {
        const nodeEl = document.querySelector(`.editor-line[data-node-id="${id}"]`);
        if (nodeEl) { nodeEl.classList.add('dragging'); setTimeout(() => nodeEl.classList.add('drag-ghost'), 0); }
      });
    });

    el.addEventListener('dragend', () => {
      DragManager.draggingIds.forEach(id => {
        const nodeEl = document.querySelector(`.editor-line[data-node-id="${id}"]`);
        if (nodeEl) nodeEl.classList.remove('dragging', 'drag-ghost');
      });
      DragManager.endDrag();
    });

    el.addEventListener('dragover', (e) => {
      e.preventDefault(); e.stopPropagation();
      if (!DragManager.draggingIds.length || DragManager.draggingIds.includes(nodeId)) return;
      for (let id of DragManager.draggingIds) { if (ASTManager.isAncestor(id, nodeId)) return; }

      e.dataTransfer.dropEffect = 'move';
      const rect = el.getBoundingClientRect();
      const y = e.clientY - rect.top, h = rect.height;

      document.querySelectorAll('.drop-indicator').forEach(d => d.remove());
      document.querySelectorAll('.drop-target-inside').forEach(d => d.classList.remove('drop-target-inside'));

      const targetNode = ASTManager.findNode(nodeId);
      const hasChildren = targetNode && Array.isArray(targetNode.children);

      if (hasChildren && y > h * 0.25 && y < h * 0.75) {
        DragManager.dropTargetId = nodeId; DragManager.dropPosition = 'inside';
        el.classList.add('drop-target-inside');
      } else if (y <= h * 0.5) {
        DragManager.dropTargetId = nodeId; DragManager.dropPosition = 'before';
        const ind = document.createElement('div');
        ind.className = 'drop-indicator drop-indicator-before';
        el.parentNode.insertBefore(ind, el);
      } else {
        DragManager.dropTargetId = nodeId; DragManager.dropPosition = 'after';
        const ind = document.createElement('div');
        ind.className = 'drop-indicator drop-indicator-after';
        el.parentNode.insertBefore(ind, el.nextSibling);
      }
    });

    el.addEventListener('dragleave', (e) => {
      if (!el.contains(e.relatedTarget)) el.classList.remove('drop-target-inside');
    });

    el.addEventListener('drop', (e) => {
      e.preventDefault(); e.stopPropagation();
      if (DragManager.dropTargetId && DragManager.dropPosition) {
        DragManager.handleDrop(DragManager.dropTargetId, DragManager.dropPosition);
      }
    });
  },

  // ── HTML renderer for each node type ───────────────────────────────────
  _html: (n) => {
    if (!n || !n.data) return '<span style="color:red">// Nodo corrupto</span>';
    const esc = Utils.escapeHtml;
    const kw  = t  => `<span class="keyword">${esc(t)}</span>`;
    const vr  = id => { const v = VariableRegistry.get(id); return v ? `<span class="variable">${esc(v.name)}</span>` : `<span style="color:red">?</span>`; };
    const str = t  => `<span class="string">"${esc(t)}"</span>`;
    const num = x  => `<span class="number">${esc(x)}</span>`;
    const op  = o  => `<span class="operator">${esc(o)}</span>`;
    const lit = (val, displayType) => {
      if (typeof val === 'boolean') return `<span class="boolean">${val ? 'True' : 'False'}</span>`;
      if (displayType === 'string' || typeof val === 'string') return str(val);
      return num(val);
    };

    try {
      switch (n.type) {
        case 'function_def': {
          const argName = n.data.argVarId ? vr(n.data.argVarId) : '';
          const fname   = n.data.funcName ? esc(n.data.funcName) : '<span style="color:red">?</span>';
          return `${kw('def')} <span class="variable">${fname}</span>(${argName}): {`;
        }
        case 'function_call': {
          const argName = n.data.argVarId    ? vr(n.data.argVarId) : '';
          const target  = n.data.targetVarId ? `${vr(n.data.targetVarId)} ${op('=')} ` : '';
          const fname   = n.data.funcName    ? esc(n.data.funcName) : '<span style="color:red">?</span>';
          return `${target}<span class="variable">${fname}</span>(${argName})`;
        }
        case 'assign': {
          if (!n.data.expression) return '<span style="color:red">// Asignación incompleta</span>';
          const r          = n.data.expression.type === 'literal'
            ? lit(n.data.expression.value, n.data.expression.valueType)
            : vr(n.data.expression.varId);
          const actualOp   = n.data.operator || '=';
          const displayOp  = actualOp.replace('=', '') || '=';
          return `(${vr(n.data.targetVarId)}) ${op(displayOp)} ${r}`;
        }
        case 'read': {
          const promptText = n.data.prompt ? ` ${str(n.data.prompt)}` : '';
          return `${kw('Read')}${promptText} → (${vr(n.data.targetVarId)})`;
        }
        case 'show': {
          const parts = (n.data.parts || []).map(p => p && p.type === 'text' ? str(p.value) : vr(p && p.varId)).join(' ');
          return `${kw('Print')} (${parts})`;
        }
        case 'if': {
          if (!n.data.condition) return '<span style="color:red">// Si incompleto</span>';
          const c     = n.data.condition;
          const right = c.rightType === 'variable'
            ? vr(c.rightVarId)
            : (typeof c.rightValue === 'boolean'
                ? `<span class="boolean">${c.rightValue ? 'True' : 'False'}</span>`
                : (typeof c.rightValue === 'string' ? str(c.rightValue) : num(c.rightValue)));
          return `${kw('si')} (${vr(c.leftVarId)} ${op(c.operator)} ${right}): {`;
        }
        case 'while': {
          if (n.data.isInfinite) return `${kw('Loop infinito')} {`;
          if (!n.data.condition) return '<span style="color:red">// Mientras incompleto</span>';
          const c     = n.data.condition;
          const right = typeof c.rightValue === 'boolean'
            ? `<span class="boolean">${c.rightValue ? 'True' : 'False'}</span>`
            : (typeof c.rightValue === 'string' ? str(c.rightValue) : num(c.rightValue));
          return `${kw('mientras')} (${vr(c.leftVarId)} ${op(c.operator)} ${right}): {`;
        }
        case 'loop':
          return `${kw('Loop')} {`;
        case 'break':
          return `${kw('break')}`;
        case 'for': {
          const iName           = n.data.iterName || 'i';
          const iteratorDisplay = `<span class="variable">${esc(iName)}</span>`;
          if (n.data.subType === 'iterable') {
            return `${kw('Para')} (${iteratorDisplay}) ${kw('en')} (${vr(n.data.iterableVarId)}) {`;
          } else {
            const endVal = (n.data.end === null || n.data.end === undefined) ? '?' : n.data.end;
            return `${kw('Para')} (${iteratorDisplay}) ${kw('en')} ${kw('Rango')}[${num(endVal)}] {`;
          }
        }
        default:
          return esc('// Instrucción desconocida');
      }
    } catch (e) {
      console.error("Error renderizando nodo", n, e);
      return '<span style="color:red">// Error de renderizado</span>';
    }
  },

  // ── Else header line ────────────────────────────────────────────────────
  _createElseHeader: (ifNode, level) => {
    const el = document.createElement('div');
    el.className        = 'editor-line else-header-line';
    el.dataset.elseFor  = ifNode.id;

    const num = document.createElement('div');
    num.className = 'line-number';
    num.innerText = EditorRenderer.lineCounter++;

    const content = document.createElement('div');
    content.className = `line-content indent-${level}`;
    content.innerHTML = `<span class="bracket">}</span> <span class="keyword">else</span> <span class="bracket">{</span>`;

    const downBtn = document.createElement('div');
    downBtn.className = 'down-btn';
    downBtn.innerText = '↓';
    downBtn.onclick   = (e) => {
      e.stopPropagation();
      ASTManager.addNode('empty', {}, ifNode.id + ':else', 'START');
    };

    const plus = document.createElement('div');
    plus.className = 'plus-icon';
    plus.innerText = '+';
    plus.onclick   = (e) => {
      e.stopPropagation();
      ContextMenuManager.show(e.clientX, e.clientY, ifNode.id + ':else', null, null);
    };

    el.append(EditorRenderer._hiddenHandle(), num, content, downBtn, plus,
              EditorRenderer._disabledBtn('line-del-btn', '×'));
    EditorRenderer.container.appendChild(el);
  },

  // ── Else closing brace ───────────────────────────────────────────────────
  _createElseCloser: (ifNode, level) => {
    const el = document.createElement('div');
    el.className        = 'editor-line closer-line else-closer-line';
    el.dataset.closerFor = ifNode.id + ':else';

    const num = document.createElement('div');
    num.className = 'line-number';
    num.innerText = EditorRenderer.lineCounter++;

    const content = document.createElement('div');
    content.className = `line-content indent-${level}`;
    content.innerHTML = `<span class="bracket">}</span> <span class="keyword">End else</span>`;

    const downBtn = document.createElement('div');
    downBtn.className = 'down-btn';
    downBtn.innerText = '↓';
    downBtn.onclick   = (e) => {
      e.stopPropagation();
      // Insert after the parent if node in its parent container
      const ifParent = ASTManager.findParent(ifNode.id);
      if (ifParent) ASTManager.addNode('empty', {}, ifParent.id, ifNode.id);
    };

    const plus = document.createElement('div');
    plus.className = 'plus-icon';
    plus.innerText = '+';
    plus.onclick   = (e) => {
      e.stopPropagation();
      const ifParent = ASTManager.findParent(ifNode.id);
      if (ifParent) ContextMenuManager.show(e.clientX, e.clientY, ifParent.id, ifNode.id, null);
    };

    el.append(EditorRenderer._hiddenHandle(), num, content, downBtn, plus,
              EditorRenderer._disabledBtn('line-del-btn', '×'));
    EditorRenderer.container.appendChild(el);
  },

  // ── DOM helpers ─────────────────────────────────────────────────────────
  _hiddenHandle: () => {
    const d = document.createElement('div');
    d.className        = 'drag-handle';
    d.style.visibility = 'hidden';
    return d;
  },

  _disabledBtn: (cls, text = '') => {
    const d = document.createElement('div');
    d.className          = cls;
    d.innerText          = text;
    d.style.opacity      = '0';
    d.style.pointerEvents = 'none';
    return d;
  }
};

window.EditorRenderer = EditorRenderer;
