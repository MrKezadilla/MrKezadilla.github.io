/* ============================================
   CODEFLOW - PanelManager
   Controla los paneles flotantes: apertura,
   cierre, arrastre y listas de vars/funcs.
   Depende de: Utils, VariableRegistry,
               FunctionRegistry, FormManager,
               Validador (opcional)
============================================ */

const PanelManager = {
  init: function() {
    document.querySelectorAll('.floating-panel-header').forEach(h => h.addEventListener('mousedown', this.drag));
    document.querySelectorAll('.floating-panel-close').forEach(b => b.onclick = this.closeAll);
  },

  drag: function(e) {
    e.preventDefault();
    const target = this.parentElement.classList.contains('floating-panel')
      ? this.parentElement
      : this.closest('.context-menu-popup');
    if (!target) return;
    target.dataset.moved = "true";
    const offX = e.clientX - target.getBoundingClientRect().left;
    const offY = e.clientY - target.getBoundingClientRect().top;
    const mv = (ev) => { target.style.left = (ev.clientX - offX) + 'px'; target.style.top = (ev.clientY - offY) + 'px'; };
    const up = () => { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); };
    document.addEventListener('mousemove', mv);
    document.addEventListener('mouseup', up);
  },

  open: (id) => {
    document.querySelectorAll('.floating-panel').forEach(p => p.classList.remove('active'));
    const p = document.getElementById(id);
    if (!p) return;

    p.classList.add('active');
    if (p.dataset.moved !== "true") {
      const rect = p.getBoundingClientRect();
      p.style.left = (window.innerWidth / 2 - rect.width / 2) + 'px';
      p.style.top  = '150px';
    }

    if (id === 'panelFormShow') { FormManager.showParts = []; FormManager.renderPreview(); }
    if (id === 'panelFormFor') {
      const rangeRadio = p.querySelector('input[value="range"]');
      if (rangeRadio) { rangeRadio.checked = true; rangeRadio.dispatchEvent(new Event('change')); }
    }
    if (typeof window.Validador !== 'undefined') {
      if (id === 'panelFormAssign') window.Validador.enforceTypes('assign');
      if (id === 'panelFormIf')     window.Validador.enforceTypes('if');
      if (id === 'panelFormWhile')  window.Validador.enforceTypes('while');
    }

    const inp = p.querySelector('input[type="text"]:not([readonly]), input[type="number"], select');
    if (inp) setTimeout(() => inp.focus(), 50);

    FormManager.updateAllSelects();
  },

  closeAll: () => {
    document.querySelectorAll('.floating-panel.active form').forEach(f => { try { f.reset(); } catch (e) {} });
    document.querySelectorAll('.floating-panel').forEach(p => p.classList.remove('active'));
    FormManager.editNodeId = null;
    FormManager.editFuncId = null;
    FormManager.showParts  = [];
  },

  renderVarsList: () => {
    const c = document.getElementById('varsListContainer');
    if (!c) return;
    const vars = VariableRegistry.getAll();
    if (vars.length === 0) { c.innerHTML = '<div style="padding:10px;text-align:center;color:#ccc">Vacío</div>'; return; }
    c.innerHTML = '';
    vars.forEach(v => {
      const typeLabels = { boolean: 'Bool', list: 'List' };
      const typeLabel  = typeLabels[v.type] || v.type;
      const item = document.createElement('div');
      item.className = 'manage-item';
      item.innerHTML = `<span><b>${Utils.escapeHtml(v.name)}</b> <small>(${Utils.escapeHtml(typeLabel)})</small></span><div class="manage-actions"><button class="del-var-btn">×</button></div>`;
      item.querySelector('.del-var-btn').addEventListener('click', () => VariableRegistry.delete(v.id));
      c.appendChild(item);
    });
  },

  renderFuncsList: () => {
    const c = document.getElementById('funcsListContainer');
    if (!c) return;
    const funcs = FunctionRegistry.getAll();
    if (funcs.length === 0) { c.innerHTML = '<div style="padding:10px;text-align:center;color:#ccc">Vacío</div>'; return; }
    c.innerHTML = '';
    funcs.forEach(f => {
      const item = document.createElement('div');
      item.className = 'manage-item';
      item.innerHTML = `<span>${Utils.escapeHtml(f.name)}()</span><div class="manage-actions"><button class="del-func-btn">×</button></div>`;
      item.querySelector('.del-func-btn').addEventListener('click', () => FunctionRegistry.delete(f.id));
      c.appendChild(item);
    });
  }
};

window.PanelManager = PanelManager;
