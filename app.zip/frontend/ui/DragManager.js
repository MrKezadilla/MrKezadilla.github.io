/* ============================================
   CODEFLOW - DragManager
   Drag & drop de nodos entre líneas del editor.
   Depende de: ASTManager, SelectionManager,
               EditorRenderer, StorageManager,
               HistoryManager
============================================ */

const DragManager = {
  draggingIds:  [],
  dropTargetId: null,
  dropPosition: null,

  startDrag: (nodeId) => {
    if (SelectionManager.active && SelectionManager.selectedIds.has(nodeId)) {
      DragManager.draggingIds = Array.from(SelectionManager.selectedIds);
    } else {
      DragManager.draggingIds = [nodeId];
    }
    document.body.classList.add('is-dragging');
  },

  endDrag: () => {
    DragManager.draggingIds  = [];
    DragManager.dropTargetId = null;
    DragManager.dropPosition = null;
    document.body.classList.remove('is-dragging');
    document.querySelectorAll('.drop-indicator').forEach(el => el.remove());
    document.querySelectorAll('.drop-target-inside').forEach(el => el.classList.remove('drop-target-inside'));
  },

  handleDrop: (targetNodeId, position) => {
    const draggingIds = DragManager.draggingIds;
    if (!draggingIds.length || draggingIds.includes(targetNodeId)) { DragManager.endDrag(); return; }

    const targetNode = ASTManager.findNode(targetNodeId);
    if (!targetNode) { DragManager.endDrag(); return; }

    for (let id of draggingIds) {
      if (ASTManager.isAncestor(id, targetNodeId)) { DragManager.endDrag(); return; }
    }

    const targetParentId = position === 'inside'
      ? targetNodeId
      : (ASTManager.findParent(targetNodeId)?.id || 'root');

    const destinoEsLoopOEstaEnLoop = (() => {
      if (targetParentId === 'root' || (typeof targetParentId === 'string' && targetParentId.startsWith('func:'))) return false;
      const tn = ASTManager.findNode(targetParentId);
      if (tn && ['loop', 'while', 'for'].includes(tn.type)) return true;
      return ASTManager.isInsideLoopByParentId(targetParentId);
    })();

    for (let id of draggingIds) {
      const n = ASTManager.findNode(id);
      if (n && ASTManager.containsBreak(n) && !destinoEsLoopOEstaEnLoop) {
        alert("No se puede mover un 'break' (o un bloque que lo contiene) fuera de un loop.");
        DragManager.endDrag();
        return;
      }
    }

    HistoryManager.saveState();

    if (position === 'inside') {
      if (!targetNode.children) { DragManager.endDrag(); return; }
      draggingIds.forEach(id => {
        const node = ASTManager.findNode(id), oldParent = ASTManager.findParent(id);
        if (node && oldParent) {
          const idx = oldParent.children.findIndex(n => n.id === id);
          if (idx !== -1) oldParent.children.splice(idx, 1);
          ASTManager._afterMutate(oldParent);
          node.parentId = targetNodeId;
          targetNode.children.push(node);
          ASTManager._afterMutate(targetNode);
        }
      });
    } else {
      const targetParent = ASTManager.findParent(targetNodeId);
      if (!targetParent) { DragManager.endDrag(); return; }
      const nodesToMove = [];
      draggingIds.forEach(id => {
        const node = ASTManager.findNode(id), oldParent = ASTManager.findParent(id);
        if (node && oldParent) {
          const idx = oldParent.children.findIndex(n => n.id === id);
          if (idx !== -1) oldParent.children.splice(idx, 1);
          ASTManager._afterMutate(oldParent);
          node.parentId = targetParent.id;
          nodesToMove.push(node);
        }
      });
      let targetIndex = targetParent.children.findIndex(c => c.id === targetNodeId);
      if (targetIndex === -1) targetIndex = targetParent.children.length;
      const insertIndex = position === 'after' ? targetIndex + 1 : targetIndex;
      targetParent.children.splice(insertIndex, 0, ...nodesToMove);
      ASTManager._afterMutate(targetParent);
    }

    EditorRenderer.render();
    StorageManager.saveLocal();
    DragManager.endDrag();
  }
};

// Clean up drag state when the user releases outside the window
document.addEventListener('dragend', () => { if (DragManager.draggingIds.length) DragManager.endDrag(); });
window.addEventListener('blur',      () => { if (DragManager.draggingIds.length) DragManager.endDrag(); });

window.DragManager = DragManager;
