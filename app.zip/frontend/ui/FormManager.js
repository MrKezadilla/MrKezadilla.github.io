/* ============================================
   CODEFLOW - FormManager
   Todos los formularios: alta de nodos,
   edición, Print builder, toggles de UI.
   Depende de: Utils, ASTManager, VariableRegistry,
               FunctionRegistry, PanelManager,
               ContextMenuManager, Validador (opt.)
============================================ */

const FormManager = {
  targetId:     'root',
  insertAfterId: null,
  replaceNodeId: null,
  editNodeId:    null,
  editFuncId:    null,
  activeNode:    null,
  showParts:     [],

  init: () => {
    const getStr = (d, key) => { const v = d.get(key); return (typeof v === 'string') ? v.trim() : ''; };

    // ── Buttons to open management panels ────────────────────────────────
    document.getElementById('btnManageVars').onclick  = () => PanelManager.open('panelManageVars');
    document.getElementById('btnManageFuncs').onclick = () => PanelManager.open('panelManageFuncs');

    // ── Add variable ──────────────────────────────────────────────────────
    document.getElementById('formAddVar').onsubmit = (e) => {
      e.preventDefault();
      const d   = new FormData(e.target);
      const res = VariableRegistry.create(getStr(d, 'varName'), d.get('varType'));
      if (!res.success) alert(res.error);
      else { e.target.reset(); FormManager.updateAllSelects(); }
    };

    // ── Add function (simple form) ────────────────────────────────────────
    document.getElementById('formAddFunc').onsubmit = (e) => {
      e.preventDefault();
      const d   = new FormData(e.target);
      const res = FunctionRegistry.create(getStr(d, 'funcName'));
      if (!res.success) alert(res.error);
      else e.target.reset();
    };

    // ── Define / edit function (with arg + return) ────────────────────────
    document.getElementById('formDefFunc').onsubmit = (e) => {
      e.preventDefault();
      const d     = new FormData(e.target);
      const fName = getStr(d, 'funcName');
      if (!fName) { alert("Indica un nombre para la función"); return; }
      const argId = d.get('argVarId')    || null;
      const retId = d.get('returnVarId') || null;

      if (FormManager.editFuncId) {
        const res = FunctionRegistry.update(FormManager.editFuncId, { name: fName, argVarId: argId, returnVarId: retId });
        if (!res.success) { alert(res.error); return; }
      } else {
        const res = FunctionRegistry.create(fName);
        if (!res.success) { alert(res.error); return; }
        FunctionRegistry.update(res.id, { argVarId: argId, returnVarId: retId });
      }
      FormManager.editFuncId = null;
      PanelManager.closeAll(); e.target.reset();
    };

    // ── Call function ─────────────────────────────────────────────────────
    document.getElementById('formCallFunc').onsubmit = (e) => {
      e.preventDefault();
      const d    = new FormData(e.target);
      const func = FunctionRegistry.get(d.get('funcId'));
      if (!func) { alert("Selecciona una función válida"); return; }
      const data = { funcName: func.name, argVarId: d.get('argVarId') || null, targetVarId: d.get('targetVarId') || null };
      if (FormManager.editNodeId) ASTManager.updateNode(FormManager.editNodeId, data);
      else ASTManager.addNode('function_call', data, FormManager.targetId, FormManager.insertAfterId, FormManager.replaceNodeId);
      PanelManager.closeAll(); e.target.reset();
    };

    // ── Print (show) builder ──────────────────────────────────────────────
    const addP = (p) => { FormManager.showParts.push(p); FormManager.renderPreview(); };
    document.getElementById('btnAddText').onclick   = () => { const i = document.getElementById('builderTextInput'); if (i.value) { addP({ type: 'text', value: i.value }); i.value = ''; } };
    document.getElementById('btnAddVar').onclick    = () => { const s = document.getElementById('builderVarSelect'); if (s.value) addP({ type: 'variable', varId: s.value }); };
    document.getElementById('btnResetMsg').onclick  = () => { FormManager.showParts = []; FormManager.renderPreview(); };
    document.getElementById('btnUndoPart').onclick  = () => { FormManager.showParts.pop(); FormManager.renderPreview(); };

    document.getElementById('btnSaveShow').onclick = () => {
      if (FormManager.showParts.length === 0) return alert("Vacío");
      const data = { parts: [...FormManager.showParts] };
      if (FormManager.editNodeId) ASTManager.updateNode(FormManager.editNodeId, data);
      else ASTManager.addNode('show', data, FormManager.targetId, FormManager.insertAfterId, FormManager.replaceNodeId);
      PanelManager.closeAll();
    };

    // ── Generic form bind helper ──────────────────────────────────────────
    const bind = (id, fn) => {
      document.getElementById(id).onsubmit = e => {
        e.preventDefault(); fn(new FormData(e.target));
        PanelManager.closeAll();
      };
    };

    // ── Assign ───────────────────────────────────────────────────────────
    bind('formAssign', d => {
      const targetVar = VariableRegistry.get(d.get('targetVarId'));
      if (!targetVar) { alert("Selecciona una variable destino válida"); return; }
      const ex = { type: d.get('valType') || 'literal', valueType: targetVar.type };
      if (ex.type === 'literal') {
        const raw = d.get('literalVal')
          || document.querySelector('#formAssign select[name*="Bool"]')?.value
          || document.querySelector('#formAssign input[name*="Num"]')?.value;
        if      (ex.valueType === 'number')  ex.value = Utils.safeNumber(raw, 0);
        else if (ex.valueType === 'boolean') ex.value = (raw === 'true' || raw === '1');
        else if (ex.valueType === 'list')    ex.value = [];
        else                                 ex.value = (raw === null || raw === undefined) ? "" : String(raw);
      } else {
        const sourceVar = VariableRegistry.get(d.get('sourceVarId'));
        if (!sourceVar) { alert("Selecciona una variable origen válida"); return; }
        ex.varId = d.get('sourceVarId');
      }
      const data = { targetVarId: d.get('targetVarId'), operator: d.get('operator') || '=', expression: ex };
      if (FormManager.editNodeId) ASTManager.updateNode(FormManager.editNodeId, data);
      else ASTManager.addNode('assign', data, FormManager.targetId, FormManager.insertAfterId, FormManager.replaceNodeId);
    });

    // ── Read ──────────────────────────────────────────────────────────────
    bind('formRead', d => {
      const targetVar = VariableRegistry.get(d.get('targetVarId'));
      if (!targetVar) { alert("Selecciona una variable válida para leer"); return; }
      const prompt = d.get('prompt')?.trim() || '';
      const data = { targetVarId: d.get('targetVarId'), prompt };
      if (FormManager.editNodeId) ASTManager.updateNode(FormManager.editNodeId, data);
      else ASTManager.addNode('read', data, FormManager.targetId, FormManager.insertAfterId, FormManager.replaceNodeId);
    });

    // ── If / While ────────────────────────────────────────────────────────
    bind('formIf',    d => FormManager.addCond('if',    d));
    bind('formWhile', d => FormManager.addCond('while', d));

    // ── For ───────────────────────────────────────────────────────────────
    bind('formFor', d => {
      const type  = d.get('forType') || 'range';
      let   iName = getStr(d, 'iterName') || 'i';
      if (!Utils.isValidName(iName)) {
        alert(`El nombre del iterador '${iName}' no es válido. Usa solo letras, números y _ (sin keywords de Python).`);
        return;
      }
      const data = { subType: type, iterName: iName };
      if (type === 'iterable') {
        const iterVar = VariableRegistry.get(d.get('iterableVarId'));
        if (!iterVar) { alert("Selecciona una variable iterable válida"); return; }
        data.iterableVarId = d.get('iterableVarId');
      } else {
        data.start = 0;
        const end  = Utils.safeInt(d.get('endVal'), 0);
        if (end < 0) { alert("El valor final del rango debe ser >= 0"); return; }
        data.end   = end;
      }
      if (FormManager.editNodeId) ASTManager.updateNode(FormManager.editNodeId, data);
      else ASTManager.addNode('for', data, FormManager.targetId, FormManager.insertAfterId, FormManager.replaceNodeId);
    });

    FormManager.setupToggles();
    if (typeof window.Validador !== 'undefined') window.Validador.init();
  },

  // ── If / While condition handler ────────────────────────────────────────
  addCond: (t, d) => {
    const l      = d.get('leftVarId');
    const isInfiniteCheck = t === 'while' && !!document.getElementById('whileIsInfinite')?.checked;
    const target = VariableRegistry.get(l);
    if (!target && !isInfiniteCheck) {
      alert(!VariableRegistry.hasVars()
        ? "Crea al menos una variable antes de usar Si/Mientras"
        : "Selecciona una variable válida");
      return;
    }
    let rv = d.get('rightVal') || d.get('rightValBool') || d.get('rightValNum');
    if      (target.type === 'boolean') rv = (rv === 'true');
    else if (target.type === 'number')  rv = Utils.safeNumber(rv, 0);
    else if (rv === null || rv === undefined) rv = "";
    const hasElse   = t === 'if'    && !!document.getElementById('ifHasElse')?.checked;
    const isInfinite = t === 'while' && !!document.getElementById('whileIsInfinite')?.checked;
    const data = {
      condition: isInfinite ? null : { leftVarId: l, leftType: target.type, operator: d.get('operator') || '==', rightType: 'literal', rightValue: rv },
      hasElse,
      isInfinite
    };
    if (FormManager.editNodeId) {
      const existing = ASTManager.findNode(FormManager.editNodeId);
      ASTManager.updateNodeWithElse(FormManager.editNodeId, data, hasElse, existing?.elseChildren || null);
    } else {
      ASTManager.addNodeWithElse(t, data, hasElse, FormManager.targetId, FormManager.insertAfterId, FormManager.replaceNodeId);
    }
  },

  // ── Load function for editing ───────────────────────────────────────────
  loadFunctionForEdit: (funcId) => {
    const f = FunctionRegistry.get(funcId);
    if (!f) return;
    FormManager.editFuncId = funcId;
    FormManager.editNodeId = null;
    PanelManager.open('panelFormDefFunc');
    const setVal = (sel, val) => { const el = document.querySelector(sel); if (el) el.value = val; };
    setVal('#formDefFunc input[name="funcName"]',     f.name);
    setVal('#formDefFunc select[name="argVarId"]',    f.argVarId    || '');
    setVal('#formDefFunc select[name="returnVarId"]', f.returnVarId || '');
  },

  // ── Load node for editing ───────────────────────────────────────────────
  loadNodeForEdit: (node) => {
    FormManager.editNodeId = node.id;
    const d      = node.data;
    const setVal = (sel, val) => { const el = document.querySelector(sel); if (el) el.value = val; };
    const setRadio = (name, val) => {
      const el = document.querySelector(`input[name="${name}"][value="${val}"]`);
      if (el) { el.checked = true; el.dispatchEvent(new Event('change')); }
    };

    switch (node.type) {
      case 'assign':
        PanelManager.open('panelFormAssign');
        setVal('#formAssign select[name="targetVarId"]', d.targetVarId);
        setVal('#formAssign select[name="operator"]',    d.operator);
        setRadio('valType', d.expression.type);
        if (d.expression.type === 'literal') {
          const targetSelect = document.getElementById('assignVarSelect');
          targetSelect.value = d.targetVarId;
          targetSelect.dispatchEvent(new Event('change'));
          setTimeout(() => {
            setVal('#formAssign input[name="literalValNum"]',    d.expression.value);
            setVal('#formAssign select[name="literalValBool"]',  d.expression.value);
            setVal('#formAssign input[name="literalVal"]',       d.expression.value);
          }, 50);
        } else {
          setVal('#formAssign select[name="sourceVarId"]', d.expression.varId);
        }
        break;

      case 'read':
        PanelManager.open('panelFormRead');
        setVal('#formRead select[name="targetVarId"]', d.targetVarId);
        setVal('#formRead input[name="prompt"]',       d.prompt || '');
        break;

      case 'show':
        PanelManager.open('panelFormShow');
        FormManager.showParts = [...(d.parts || [])];
        FormManager.renderPreview();
        break;

      case 'if':
      case 'while': {
        PanelManager.open(node.type === 'if' ? 'panelFormIf' : 'panelFormWhile');
        const prefix = node.type === 'if' ? '#formIf' : '#formWhile';
        const leftSelect = document.querySelector(`${prefix} select[name="leftVarId"]`);
        if (leftSelect) { leftSelect.value = d.condition.leftVarId; leftSelect.dispatchEvent(new Event('change')); }
        setVal(`${prefix} select[name="operator"]`, d.condition.operator);
        setTimeout(() => {
          setVal(`${prefix} input[name="rightValNum"]`,   d.condition.rightValue);
          setVal(`${prefix} select[name="rightValBool"]`, d.condition.rightValue);
          setVal(`${prefix} input[name="rightVal"]`,      d.condition.rightValue);
        }, 50);
        // Restore else toggle
        if (node.type === 'if') {
          const toggle = document.getElementById('ifHasElse');
          if (toggle) toggle.checked = !!(node.elseChildren !== null && node.elseChildren !== undefined);
        }
        // Restore infinite toggle and show/hide condition rows
        if (node.type === 'while') {
          const toggle   = document.getElementById('whileIsInfinite');
          const condRows = document.getElementById('whileConditionRows');
          if (toggle && condRows) {
            toggle.checked = !!d.isInfinite;
            condRows.style.display = d.isInfinite ? 'none' : 'block';
            condRows.querySelectorAll('[required]').forEach(el => { el.required = !d.isInfinite; });
          }
        }
        break;
      }

      case 'for':
        PanelManager.open('panelFormFor');
        setRadio('forType', d.subType);
        setVal('#formFor input[name="iterName"]', d.iterName);
        if (d.subType === 'range') setVal('#formFor input[name="endVal"]', d.end);
        else                       setVal('#formFor select[name="iterableVarId"]', d.iterableVarId);
        break;

      case 'function_call': {
        PanelManager.open('panelFormCallFunc');
        const func = FunctionRegistry.getAll().find(f => f.name === d.funcName);
        if (func) setVal('#formCallFunc select[name="funcId"]', func.id);
        setVal('#formCallFunc select[name="argVarId"]',    d.argVarId    || '');
        setVal('#formCallFunc select[name="targetVarId"]', d.targetVarId || '');
        break;
      }

      default:
        alert('Esta instrucción no tiene parámetros para editar. Intenta la opción Reemplazar.');
        FormManager.editNodeId = null;
        break;
    }
  },

  // ── Print preview ─────────────────────────────────────────────────────
  renderPreview: () => {
    document.getElementById('msgBuilderPreview').innerHTML = FormManager.showParts.map(p =>
      p.type === 'text'
        ? `<span class="msg-part msg-txt">${p.value}</span>`
        : `<span class="msg-part msg-var">${VariableRegistry.get(p.varId)?.name}</span>`
    ).join('') || '<span style="color:#ccc;font-size:12px">Vacío...</span>';
  },

  // ── Refresh all select dropdowns ──────────────────────────────────────
  updateAllSelects: () => {
    const vars  = VariableRegistry.getAll();
    const funcs = FunctionRegistry.getAll();

    document.querySelectorAll('.var-select').forEach(s => {
      const v = s.value;
      s.innerHTML = '<option value="">-- Opcional / Elegir --</option>';
      vars.forEach(x => {
        const o = document.createElement('option');
        o.value = x.id; o.text = x.name;
        s.appendChild(o);
      });
      if (s.hasAttribute('required')) s.querySelector('option[value=""]')?.remove();
      if (vars.find(x => x.id === v)) s.value = v;
      if (s.id === 'assignVarSelect' || s.id === 'builderVarSelect') {
        const msg = s.closest('.form-row')?.querySelector('.no-variables-msg');
        if (msg) msg.style.display = vars.length ? 'none' : 'block';
      }
    });

    document.querySelectorAll('.func-select').forEach(s => {
      const v = s.value;
      s.innerHTML = '';
      funcs.forEach(f => {
        const o = document.createElement('option');
        o.value = f.id; o.text = f.name;
        s.appendChild(o);
      });
      if (funcs.find(x => x.id === v)) s.value = v;
      const msg = s.closest('.form-row')?.querySelector('.no-functions-msg');
      if (msg) msg.style.display = funcs.length ? 'none' : 'block';
    });

    // ── List-only selects (for iterable) ──────────────────────────────────
    const listVars = vars.filter(x => x.type === 'list');
    document.querySelectorAll('.list-var-select').forEach(s => {
      const v = s.value;
      s.innerHTML = '<option value="">-- Elegir lista --</option>';
      listVars.forEach(x => {
        const o = document.createElement('option');
        o.value = x.id; o.text = x.name;
        s.appendChild(o);
      });
      if (listVars.find(x => x.id === v)) s.value = v;
      const row = s.closest('.form-row');
      if (row) {
        const msg = row.querySelector('.no-variables-msg');
        if (msg) msg.style.display = listVars.length ? 'none' : 'block';
        if (listVars.length === 0) {
          s.title = 'Crea una variable de tipo Lista primero';
        } else {
          s.title = '';
        }
      }
    });

    if (typeof window.Validador !== 'undefined') {
      if (document.getElementById('panelFormAssign')?.classList.contains('active')) window.Validador.enforceTypes('assign');
      if (document.getElementById('panelFormIf')?.classList.contains('active'))     window.Validador.enforceTypes('if');
      if (document.getElementById('panelFormWhile')?.classList.contains('active'))  window.Validador.enforceTypes('while');
    }
  },

  // ── Radio toggle UI ───────────────────────────────────────────────────
  setupToggles: () => {
    document.querySelectorAll('input[type=radio]').forEach(r => r.addEventListener('change', () => {
      if (r.name === 'valType') {
        document.getElementById('asnLitRow').style.display = r.value === 'literal'  ? 'block' : 'none';
        document.getElementById('asnVarRow').style.display = r.value === 'variable' ? 'block' : 'none';
      }
      if (r.name === 'compareType') {
        const litInput    = document.querySelector('#formIf input[name*="rightVal"], #formIf select[name*="rightVal"]');
        const varSelectRow = document.getElementById('ifRightVarRow');
        if (litInput && varSelectRow) {
          litInput.parentNode.style.display = r.value === 'value'    ? 'block' : 'none';
          varSelectRow.style.display        = r.value === 'variable' ? 'block' : 'none';
        }
      }
      if (r.name === 'forType') {
        const isRange = r.value === 'range';
        document.getElementById('forRangeRow').style.display = isRange ? 'flex'  : 'none';
        document.getElementById('forIterRow').style.display  = isRange ? 'none'  : 'block';
        const iterInput = document.querySelector('input[name="iterName"]');
        if (iterInput) {
          if (isRange) {
            iterInput.value           = 'i';
            iterInput.readOnly        = true;
            iterInput.style.backgroundColor = '#f1f5f9';
            iterInput.style.color    = '#94a3b8';
          } else {
            iterInput.readOnly        = false;
            iterInput.value           = '';
            iterInput.placeholder     = 'Ej: item';
            iterInput.style.backgroundColor = '#ffffff';
            iterInput.style.color    = 'var(--color-text-primary)';
            FormManager.updateAllSelects();
          }
        }
      }
    }));
  }
};

window.FormManager = FormManager;
