/* ============================================
   CODEFLOW - ContextMenuManager
   Menú contextual de instrucciones (click en +)
   y menú de edición (click en ✎).
   Depende de: ASTManager, VariableRegistry,
               FormManager, PanelManager
============================================ */

const ContextMenuManager = {
  init: function() {
    const h = document.getElementById('dragMenuHandle');
    if (h) h.addEventListener('mousedown', PanelManager.drag);
  },

  show: (x, y, pid, insertAfterId = null, replaceNodeId = null) => {
    FormManager.targetId     = pid;
    FormManager.insertAfterId = insertAfterId;
    FormManager.replaceNodeId = replaceNodeId;

    const m = document.getElementById('quickContextMenu');
    m.style.left    = x + 'px';
    m.style.top     = y + 'px';
    m.style.display = 'block';

    const noVars = !VariableRegistry.hasVars();
    ['open-assign', 'open-read'].forEach(act => {
      const el = m.querySelector(`[data-action="${act}"]`);
      if (el) el.classList.toggle('disabled', noVars);
    });

    const breakItem = m.querySelector('[data-action="open-break"]');
    if (breakItem) {
      breakItem.style.display = ContextMenuManager._isInsideLoop(pid) ? 'flex' : 'none';
    }
  },

  showEditMenu: (x, y, node) => {
    FormManager.activeNode = node;
    const m = document.getElementById('editContextMenu');
    m.style.left    = x + 'px';
    m.style.top     = y + 'px';
    m.style.display = 'block';
  },

  _isInsideLoop: (parentId) => {
    if (parentId === 'root') return false;
    const node = ASTManager.findNode(parentId);
    if (!node) return false;
    if (['loop', 'while', 'for'].includes(node.type)) return true;
    return ContextMenuManager._isInsideLoop(node.parentId);
  }
};

window.ContextMenuManager = ContextMenuManager;
