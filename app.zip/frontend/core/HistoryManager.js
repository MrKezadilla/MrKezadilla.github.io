/* ============================================
   CODEFLOW - HistoryManager
   Pila de deshacer/rehacer (hasta 50 estados).
   Depende de: Utils, ASTManager, VariableRegistry,
               FunctionRegistry, EditorRenderer,
               PanelManager, FormManager, StorageManager
============================================ */

const HistoryManager = {
  stack: [], pointer: -1, limit: 50,

  _snapshot: function() {
    return {
      ast:   Utils.clone(ASTManager.root),
      vars:  Utils.clone(Array.from(VariableRegistry._vars.entries())),
      funcs: Utils.clone(Array.from(FunctionRegistry._funcs.entries()))
    };
  },

  saveState: function() {
    if (this.pointer >= 0 && this.pointer < this.stack.length) {
      this.stack[this.pointer] = this._snapshot();
    }
    if (this.pointer < this.stack.length - 1) {
      this.stack = this.stack.slice(0, this.pointer + 1);
    }
    this.stack.push(this._snapshot());
    if (this.stack.length > this.limit) {
      this.stack.shift();
      this.pointer = this.stack.length - 1;
    } else {
      this.pointer++;
    }
    this.updateUI();
  },

  undo: function() {
    if (this.pointer > 0) {
      this.stack[this.pointer] = this._snapshot();
      this.pointer--;
      this.restore(this.stack[this.pointer]);
    }
    this.updateUI();
  },

  redo: function() {
    if (this.pointer < this.stack.length - 1) {
      this.pointer++;
      this.restore(this.stack[this.pointer]);
    }
    this.updateUI();
  },

  restore: function(s) {
    if (!s) return;
    ASTManager.root          = Utils.clone(s.ast);
    VariableRegistry._vars   = new Map(Utils.clone(s.vars));
    FunctionRegistry._funcs  = new Map(Utils.clone(s.funcs));
    EditorRenderer.render();
    PanelManager.renderVarsList();
    PanelManager.renderFuncsList();
    FormManager.updateAllSelects();
    StorageManager.saveLocal();
  },

  updateUI: function() {
    const u = document.getElementById('btnUndo');
    const r = document.getElementById('btnRedo');
    if (u) u.style.opacity = (this.pointer > 0) ? '1' : '0.4';
    if (r) r.style.opacity = (this.pointer < this.stack.length - 1) ? '1' : '0.4';
  }
};

window.HistoryManager = HistoryManager;
