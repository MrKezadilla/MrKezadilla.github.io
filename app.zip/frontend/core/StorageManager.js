/* ============================================
   CODEFLOW - StorageManager
   Persistencia en localStorage con validación
   de esquema y backup ante datos corruptos.
   Depende de: Utils, ASTManager, VariableRegistry,
               FunctionRegistry, HistoryManager,
               EditorRenderer, PanelManager,
               FormManager
============================================ */

const StorageManager = {
  KEY:        'cf_v04',
  BACKUP_KEY: 'cf_v04_backup',
  quotaWarned: false,

  saveLocal: () => {
    try {
      const payload = JSON.stringify({
        ast:   ASTManager.root,
        vars:  Array.from(VariableRegistry._vars.entries()),
        funcs: Array.from(FunctionRegistry._funcs.entries())
      });
      localStorage.setItem(StorageManager.KEY, payload);
    } catch (e) {
      if (!StorageManager.quotaWarned) {
        StorageManager.quotaWarned = true;
        console.error("CodeFlow: no se pudo guardar en localStorage:", e);
        alert("⚠️ No se pudo guardar el progreso. El almacenamiento del navegador está lleno o no disponible.");
      }
    }
  },

  _validateSchema: (s) => {
    if (!s || typeof s !== 'object') return false;
    if (!s.ast || typeof s.ast !== 'object' || !Array.isArray(s.ast.children)) return false;
    if (!Array.isArray(s.vars))  return false;
    if (!Array.isArray(s.funcs)) return false;
    for (const e of s.vars) {
      if (!Array.isArray(e) || e.length !== 2) return false;
      if (!e[1] || typeof e[1] !== 'object' || typeof e[1].name !== 'string' || typeof e[1].type !== 'string') return false;
    }
    for (const e of s.funcs) {
      if (!Array.isArray(e) || e.length !== 2) return false;
      if (!e[1] || typeof e[1] !== 'object' || typeof e[1].name !== 'string') return false;
    }
    return true;
  },

  _sanitizeAST: (node, isRoot = true) => {
    if (!node || typeof node !== 'object') return { id: 'root', type: 'program', children: [] };
    if (!node.id)   node.id   = 'root';
    if (!node.type) node.type = 'program';
    if (!isRoot && node.data === undefined) node.data = {};
    if (Array.isArray(node.children)) {
      node.children = node.children.filter(c => c && typeof c === 'object' && c.type);
      node.children.forEach(c => StorageManager._sanitizeAST(c, false));
    }
    return node;
  },

  _sanitizeFunc: (entry) => {
    if (!Array.isArray(entry) || entry.length !== 2) return null;
    const f = entry[1];
    if (!f || typeof f !== 'object' || typeof f.name !== 'string') return null;
    if (f.argVarId    === undefined) f.argVarId    = null;
    if (f.returnVarId === undefined) f.returnVarId = null;
    if (!Array.isArray(f.children)) f.children = [];
    f.children = f.children.filter(c => c && typeof c === 'object' && c.type);
    f.children.forEach(c => StorageManager._sanitizeAST(c, false));
    return entry;
  },

  loadLocal: () => {
    let raw;
    try { raw = localStorage.getItem(StorageManager.KEY); } catch (e) { raw = null; }

    if (!raw) {
      HistoryManager.saveState();
      EditorRenderer.render();
      return;
    }

    let s;
    try { s = JSON.parse(raw); }
    catch (e) {
      try { localStorage.setItem(StorageManager.BACKUP_KEY, raw); } catch (_) {}
      ASTManager.reset();
      return;
    }

    if (!StorageManager._validateSchema(s)) {
      try { localStorage.setItem(StorageManager.BACKUP_KEY, raw); } catch (_) {}
      try {
        ASTManager.root = (s && s.ast && Array.isArray(s.ast.children))
          ? StorageManager._sanitizeAST(s.ast)
          : { id: 'root', type: 'program', children: [] };
        VariableRegistry._vars = (s && Array.isArray(s.vars))
          ? new Map(s.vars.filter(e => Array.isArray(e) && e.length === 2 && e[1] && e[1].name && e[1].type))
          : new Map();
        const sanitizedFuncs = s.funcs ? s.funcs.map(StorageManager._sanitizeFunc).filter(Boolean) : [];
        FunctionRegistry._funcs = new Map(sanitizedFuncs);
      } catch (_) { ASTManager.reset(); return; }
      HistoryManager.saveState();
      EditorRenderer.render();
      VariableRegistry.notifyChange();
      FunctionRegistry.notifyChange();
      return;
    }

    try {
      ASTManager.root          = StorageManager._sanitizeAST(s.ast);
      VariableRegistry._vars   = new Map(s.vars);
      const sanitizedFuncs     = s.funcs.map(StorageManager._sanitizeFunc).filter(Boolean);
      FunctionRegistry._funcs  = new Map(sanitizedFuncs);
      HistoryManager.stack     = [{ ast: Utils.clone(ASTManager.root), vars: Utils.clone(s.vars), funcs: Utils.clone(s.funcs) }];
      HistoryManager.pointer   = 0;
      EditorRenderer.render();
      VariableRegistry.notifyChange();
      FunctionRegistry.notifyChange();
    } catch (e) {
      try { localStorage.setItem(StorageManager.BACKUP_KEY, raw); } catch (_) {}
      ASTManager.reset();
    }
  }
};

window.StorageManager = StorageManager;
