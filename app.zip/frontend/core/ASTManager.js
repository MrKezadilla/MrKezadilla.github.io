/* ============================================
   CODEFLOW - ASTManager
   El árbol de instrucciones. Operaciones:
   findNode, findParent, addNode, updateNode,
   deleteNode, purgeVarReferences, etc.
   Depende de: Utils, HistoryManager,
               VariableRegistry, FunctionRegistry,
               SelectionManager, EditorRenderer,
               StorageManager
============================================ */

const ASTManager = {
  root: { id: 'root', type: 'program', children: [] },

  reset: () => {
    HistoryManager.saveState();
    ASTManager.root = { id: 'root', type: 'program', children: [] };
    FunctionRegistry.getAll().forEach(f => { f.children.length = 0; });
    EditorRenderer.render();
    StorageManager.saveLocal();
  },

  // ── Function wrapper cache ──────────────────────────────────────────────
  _funcWrappers: new Map(),

  _getWrapperForFunc: (f) => {
    let w = ASTManager._funcWrappers.get(f.id);
    if (!w) {
      w = { id: 'func:' + f.id, type: 'function_def_body', funcRef: f, children: f.children };
      ASTManager._funcWrappers.set(f.id, w);
    } else {
      w.children = f.children;
      w.funcRef  = f;
    }
    return w;
  },

  _syncWrapperToFunc: (wrapper) => {
    if (wrapper && wrapper.funcRef) {
      wrapper.funcRef.children = wrapper.children;
    }
  },

  _getAllContainers: () => {
    const containers = [ASTManager.root];
    FunctionRegistry.getAll().forEach(f => {
      containers.push(ASTManager._getWrapperForFunc(f));
    });
    return containers;
  },

  _afterMutate: (parent) => {
    if (parent && parent.funcRef) ASTManager._syncWrapperToFunc(parent);
  },

  // ── Tree traversal ──────────────────────────────────────────────────────
  findNode: (id, node = null) => {
    if (node) {
      if (node.id === id) return node;
      // Support virtual else-container IDs like "nodeId:else"
      if (id && id.endsWith(':else') && node.id === id.slice(0, -5)) {
        return { id, type: '_else_container', parentNode: node,
                 children: node.elseChildren || [], get elseChildren(){ return null; } };
      }
      if (node.children) {
        for (let c of node.children) {
          const f = ASTManager.findNode(id, c);
          if (f) return f;
        }
      }
      if (Array.isArray(node.elseChildren)) {
        for (let c of node.elseChildren) {
          const f = ASTManager.findNode(id, c);
          if (f) return f;
        }
      }
      return null;
    }
    for (const container of ASTManager._getAllContainers()) {
      if (container.id === id) return container;
      const found = ASTManager.findNode(id, container);
      if (found) return found;
    }
    return null;
  },

  findParent: (targetId, node = null) => {
    if (node) {
      if (node.children && node.children.some(c => c.id === targetId)) return node;
      if (node.elseChildren && node.elseChildren.some(c => c.id === targetId)) {
        // Return a virtual container pointing at elseChildren
        return { id: node.id + ':else', type: '_else_container', parentNode: node,
                 children: node.elseChildren,
                 get elseChildren(){ return null; } };
      }
      for (let c of (node.children || [])) {
        const found = ASTManager.findParent(targetId, c);
        if (found) return found;
      }
      for (let c of (node.elseChildren || [])) {
        const found = ASTManager.findParent(targetId, c);
        if (found) return found;
      }
      return null;
    }
    for (const container of ASTManager._getAllContainers()) {
      const found = ASTManager.findParent(targetId, container);
      if (found) return found;
    }
    return null;
  },

  isAncestor: (ancestorId, nodeId, visited = null) => {
    if (!visited) visited = new Set();
    if (visited.has(nodeId)) return false;
    visited.add(nodeId);
    const node = ASTManager.findNode(nodeId);
    if (!node) return false;
    if (node.parentId === ancestorId) return true;
    if (!node.parentId || node.parentId === 'root' ||
        (typeof node.parentId === 'string' && node.parentId.startsWith('func:'))) {
      return node.parentId === ancestorId;
    }
    return ASTManager.isAncestor(ancestorId, node.parentId, visited);
  },

  containsBreak: (node) => {
    if (!node) return false;
    if (node.type === 'break') return true;
    if (!node.children) return false;
    return node.children.some(c => ASTManager.containsBreak(c));
  },

  isInsideLoopByParentId: (parentId) => {
    if (!parentId || parentId === 'root' ||
        (typeof parentId === 'string' && parentId.startsWith('func:'))) return false;
    const node = ASTManager.findNode(parentId);
    if (!node) return false;
    if (['loop', 'while', 'for'].includes(node.type)) return true;
    return ASTManager.isInsideLoopByParentId(node.parentId);
  },

  // ── Reference cleanup ───────────────────────────────────────────────────
  purgeVarReferences: (varId) => {
    const walk = (node) => {
      if (!node) return;
      if (node.children && Array.isArray(node.children)) {
        for (let i = node.children.length - 1; i >= 0; i--) {
          const child = node.children[i];
          if (!child || !child.data) continue;
          let shouldDelete = false;
          if (child.type === 'assign'  && child.data.targetVarId === varId)                        shouldDelete = true;
          else if (child.type === 'read'    && child.data.targetVarId === varId)                   shouldDelete = true;
          else if ((child.type === 'if' || child.type === 'while') &&
                   child.data.condition && child.data.condition.leftVarId === varId)               shouldDelete = true;
          else if (child.type === 'for'    && child.data.iterableVarId === varId)                  shouldDelete = true;
          if (shouldDelete) node.children.splice(i, 1);
        }
        node.children.forEach(child => {
          if (!child || !child.data) return;
          if (child.type === 'assign' && child.data.expression && child.data.expression.varId === varId) {
            const targetVar = VariableRegistry._vars.get(child.data.targetVarId);
            const valueType = targetVar ? targetVar.type : 'string';
            child.data.expression = { type: 'literal', valueType, value: Utils.getDefaultVal(valueType) };
          }
          if ((child.type === 'if' || child.type === 'while') &&
               child.data.condition && child.data.condition.rightVarId === varId) {
            child.data.condition.rightType  = 'literal';
            child.data.condition.rightValue = Utils.getDefaultVal(child.data.condition.leftType || 'string');
            delete child.data.condition.rightVarId;
          }
          if (child.type === 'function_call') {
            if (child.data.argVarId    === varId) child.data.argVarId    = null;
            if (child.data.targetVarId === varId) child.data.targetVarId = null;
          }
          if (child.type === 'show' && Array.isArray(child.data.parts)) {
            child.data.parts = child.data.parts.filter(p => !(p.type === 'variable' && p.varId === varId));
          }
          walk(child);
        });
      }
    };
    // Also walk elseChildren on every if node
    const walkElse = (node) => {
      if (!node) return;
      if (Array.isArray(node.elseChildren)) {
        for (let i = node.elseChildren.length - 1; i >= 0; i--) {
          const child = node.elseChildren[i];
          if (!child || !child.data) continue;
          if (child.type === 'assign'  && child.data.targetVarId === varId) { node.elseChildren.splice(i, 1); continue; }
          if (child.type === 'read'    && child.data.targetVarId === varId) { node.elseChildren.splice(i, 1); continue; }
        }
        node.elseChildren.forEach(child => {
          if (child.type === 'show' && Array.isArray(child.data?.parts))
            child.data.parts = child.data.parts.filter(p => !(p.type === 'variable' && p.varId === varId));
          walkElse(child);
        });
      }
      if (Array.isArray(node.children)) node.children.forEach(walkElse);
    };
    walkElse(ASTManager.root);
    walk(ASTManager.root);
    FunctionRegistry.getAll().forEach(f => {
      if (f.argVarId    === varId) f.argVarId    = null;
      if (f.returnVarId === varId) f.returnVarId = null;
      walk(f);
    });
  },

  purgeFuncReferences: (funcName) => {
    const walk = (node) => {
      if (!node) return;
      if (node.children && Array.isArray(node.children)) {
        for (let i = node.children.length - 1; i >= 0; i--) {
          const child = node.children[i];
          if (child && child.data && child.type === 'function_call' && child.data.funcName === funcName) {
            node.children.splice(i, 1);
          }
        }
        node.children.forEach(walk);
      }
    };
    walk(ASTManager.root);
    FunctionRegistry.getAll().forEach(walk);
  },

  renameFuncReferences: (oldName, newName) => {
    const walk = (node) => {
      if (!node || !node.children) return;
      node.children.forEach(child => {
        if (!child) return;
        if (child.type === 'function_call' && child.data && child.data.funcName === oldName) {
          child.data.funcName = newName;
        }
        walk(child);
      });
    };
    walk(ASTManager.root);
    FunctionRegistry.getAll().forEach(walk);
  },

  // ── Mutations ───────────────────────────────────────────────────────────
  addNode: (type, data, parentId = 'root', insertAfter = null, replaceNodeId = null) => {
    const parent = ASTManager.findNode(parentId);
    if (!parent) return;
    // Virtual else-container: write into the real node's elseChildren array
    const childArray = parent.type === '_else_container' ? parent.children : parent.children;
    if (!Array.isArray(childArray)) return;
    HistoryManager.saveState();
    const hasChildren = ['if', 'while', 'for', 'loop'].includes(type);
    const node = { id: Utils.generateId(), type, parentId, data, children: hasChildren ? [] : null };

    if (replaceNodeId) {
      const idx = childArray.findIndex(c => c.id === replaceNodeId);
      if (idx !== -1) childArray.splice(idx, 1, node);
      else childArray.push(node);
    } else if (insertAfter === 'START') {
      childArray.unshift(node);
    } else if (insertAfter) {
      const idx = childArray.findIndex(c => c.id === insertAfter);
      if (idx !== -1) childArray.splice(idx + 1, 0, node);
      else childArray.push(node);
    } else {
      childArray.push(node);
    }

    ASTManager._afterMutate(parent);
    EditorRenderer.render();
    StorageManager.saveLocal();
  },

  updateNode: (id, newData) => {
    const node = ASTManager.findNode(id);
    if (!node) return;
    HistoryManager.saveState();
    node.data = newData;
    EditorRenderer.render();
    StorageManager.saveLocal();
  },

  // ── else-aware mutations ────────────────────────────────────────────────
  // Adds an if node and immediately sets elseChildren if hasElse is true.
  addNodeWithElse: (type, data, hasElse, parentId = 'root', insertAfter = null, replaceNodeId = null) => {
    const parent = ASTManager.findNode(parentId);
    if (!parent || !Array.isArray(parent.children)) return;
    HistoryManager.saveState();
    const node = {
      id: Utils.generateId(), type, parentId, data,
      children:     [],
      elseChildren: (type === 'if' && hasElse) ? [] : null
    };
    if (replaceNodeId) {
      const idx = parent.children.findIndex(c => c.id === replaceNodeId);
      if (idx !== -1) parent.children.splice(idx, 1, node);
      else parent.children.push(node);
    } else if (insertAfter === 'START') {
      parent.children.unshift(node);
    } else if (insertAfter) {
      const idx = parent.children.findIndex(c => c.id === insertAfter);
      if (idx !== -1) parent.children.splice(idx + 1, 0, node);
      else parent.children.push(node);
    } else {
      parent.children.push(node);
    }
    ASTManager._afterMutate(parent);
    EditorRenderer.render();
    StorageManager.saveLocal();
  },

  // Updates an if node's data and manages elseChildren lifecycle.
  updateNodeWithElse: (id, newData, hasElse, existingElseChildren) => {
    const node = ASTManager.findNode(id);
    if (!node) return;
    HistoryManager.saveState();
    node.data = newData;
    if (hasElse) {
      // Preserve existing else body if it was already there
      node.elseChildren = existingElseChildren !== null ? existingElseChildren : [];
    } else {
      node.elseChildren = null;
    }
    EditorRenderer.render();
    StorageManager.saveLocal();
  },

  deleteNode: (id) => {
    const node = ASTManager.findNode(id);
    if (!node) return;
    if (node.children && node.children.length > 0 && !confirm("¿Borrar contenido?")) return;
    HistoryManager.saveState();
    const parent = ASTManager.findParent(id);
    if (parent) {
      const idx = parent.children.findIndex(n => n.id === id);
      if (idx !== -1) parent.children.splice(idx, 1);
      ASTManager._afterMutate(parent);
      SelectionManager.pruneDeadIds();
      EditorRenderer.render();
      StorageManager.saveLocal();
    }
  }
};

window.ASTManager = ASTManager;
