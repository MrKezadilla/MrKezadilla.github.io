/* ============================================
   CODEFLOW - Utils
   Helpers generales: IDs, clonación, escape,
   validación de nombres y conversión numérica.
============================================ */

const PYTHON_KEYWORDS = new Set([
  'False','None','True','and','as','assert','async','await','break','class',
  'continue','def','del','elif','else','except','finally','for','from','global',
  'if','import','in','is','lambda','nonlocal','not','or','pass','raise','return',
  'try','while','with','yield','print','input','range','len','list','dict','set',
  'tuple','str','int','float','bool','type','open','exec','eval'
]);

const _idCounter = { n: 0 };

const Utils = {
  generateId: () => {
    _idCounter.n++;
    return 'node_' + Date.now().toString(36) + '_' + _idCounter.n.toString(36) + '_' + Math.random().toString(36).substr(2, 5);
  },
  clone: (obj) => {
    try { return structuredClone(obj); }
    catch (e) { return JSON.parse(JSON.stringify(obj)); }
  },
  escapeHtml: (s) => {
    if (s === null || s === undefined) return '';
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  },
  isValidName: (n) => {
    if (typeof n !== 'string') return false;
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(n)) return false;
    if (PYTHON_KEYWORDS.has(n)) return false;
    return true;
  },
  validateNameWithReason: (n) => {
    if (typeof n !== 'string' || !n.trim()) return "El nombre no puede estar vacío";
    const trimmed = n.trim();
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(trimmed)) return "Solo letras, números y _ (sin empezar con número)";
    if (PYTHON_KEYWORDS.has(trimmed)) return `'${trimmed}' es una palabra reservada de Python`;
    return null;
  },
  getDefaultVal: (type) => {
    if (type === 'number')  return 0;
    if (type === 'boolean') return false;
    if (type === 'list')    return [];
    return "";
  },
  safeNumber: (raw, fallback = 0) => {
    if (raw === null || raw === undefined || raw === '') return fallback;
    const n = Number(raw);
    if (!Number.isFinite(n)) return fallback;
    return n;
  },
  safeInt: (raw, fallback = 0) => {
    const n = Utils.safeNumber(raw, fallback);
    return Math.trunc(n);
  }
};

window.Utils = Utils;
