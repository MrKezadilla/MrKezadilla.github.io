/* ============================================
   CODEFLOW - FunctionRegistry
   CRUD de funciones. Cada función tiene:
   { id, name, argVarId, returnVarId, children[] }
   Depende de: Utils, HistoryManager, ASTManager,
               SelectionManager, PanelManager,
               FormManager, EditorRenderer, StorageManager
============================================ */

const FunctionRegistry = {
  _funcs: new Map(),

  create: function(name) {
    const reason = Utils.validateNameWithReason(name);
    if (reason) return { success: false, error: reason };
    const trimmed = name.trim();
    if ([...this._funcs.values()].some(f => f.name === trimmed))
      return { success: false, error: "Ya existe una función con ese nombre" };
    HistoryManager.saveState();
    const id = Utils.generateId();
    this._funcs.set(id, { id, name: trimmed, argVarId: null, returnVarId: null, children: [] });
    this.notifyChange();
    return { success: true, id };
  },

  delete: function(id) {
    if (!confirm("¿Eliminar función? Se quitarán también las llamadas en el código.")) return;
    const func  = this._funcs.get(id);
    const fname = func ? func.name : null;
    HistoryManager.saveState();
    this._funcs.delete(id);
    if (fname) ASTManager.purgeFuncReferences(fname);
    if (ASTManager._funcWrappers) ASTManager._funcWrappers.delete(id);
    SelectionManager.pruneDeadIds();
    this.notifyChange();
  },

  update: function(id, partial) {
    const f = this._funcs.get(id);
    if (!f) return { success: false, error: "Función no encontrada" };
    HistoryManager.saveState();
    if (partial.argVarId    !== undefined) f.argVarId    = partial.argVarId;
    if (partial.returnVarId !== undefined) f.returnVarId = partial.returnVarId;
    if (partial.name        !== undefined) {
      const reason = Utils.validateNameWithReason(partial.name);
      if (reason) return { success: false, error: reason };
      const trimmed = partial.name.trim();
      if ([...this._funcs.values()].some(o => o.id !== id && o.name === trimmed))
        return { success: false, error: "Ya existe una función con ese nombre" };
      const oldName = f.name;
      f.name = trimmed;
      ASTManager.renameFuncReferences(oldName, trimmed);
    }
    this.notifyChange();
    return { success: true };
  },

  get:    (id) => FunctionRegistry._funcs.get(id),
  getAll: ()   => Array.from(FunctionRegistry._funcs.values()),

  notifyChange: () => {
    PanelManager.renderFuncsList();
    FormManager.updateAllSelects();
    EditorRenderer.render();
    StorageManager.saveLocal();
  }
};

window.FunctionRegistry = FunctionRegistry;
