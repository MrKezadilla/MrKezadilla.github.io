/* ============================================
   CODEFLOW - VariableRegistry
   CRUD de variables. Cada variable tiene:
   { id, name, type, value }
   Depende de: Utils, HistoryManager, ASTManager,
               SelectionManager, PanelManager,
               FormManager, EditorRenderer, StorageManager
============================================ */

const VariableRegistry = {
  _vars: new Map(),

  create: function(name, type) {
    const reason = Utils.validateNameWithReason(name);
    if (reason) return { success: false, error: reason };
    const trimmed = name.trim();
    if ([...this._vars.values()].some(v => v.name === trimmed))
      return { success: false, error: "Ya existe una variable con ese nombre" };
    HistoryManager.saveState();
    const id = Utils.generateId();
    this._vars.set(id, { id, name: trimmed, type, value: Utils.getDefaultVal(type) });
    this.notifyChange();
    return { success: true, id };
  },

  delete: function(id) {
    if (!confirm("¿Eliminar variable? Se quitarán también las referencias en el código.")) return;
    HistoryManager.saveState();
    this._vars.delete(id);
    ASTManager.purgeVarReferences(id);
    SelectionManager.pruneDeadIds();
    this.notifyChange();
  },

  get:    (id) => VariableRegistry._vars.get(id),
  getAll: ()   => Array.from(VariableRegistry._vars.values()),
  hasVars:()   => VariableRegistry._vars.size > 0,

  notifyChange: () => {
    PanelManager.renderVarsList();
    FormManager.updateAllSelects();
    EditorRenderer.render();
    StorageManager.saveLocal();
  }
};

window.VariableRegistry = VariableRegistry;
